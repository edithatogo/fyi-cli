from __future__ import annotations
import html
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from .dashboard import dashboard_payload
from .db import init_db, query_all, insert_tracked_request, get_tracked_request, update_tracked_request, update_request_status, request_timeline
from .fetch import latest_snapshot_summary
from .reporting import suggest_follow_up, follow_up_variants, follow_up_pack, response_analysis, triage_report
from .fyi import build_prefilled_url
from .importers import import_authorities_csv

STATUSES = ['draft', 'submitted', 'awaiting_response', 'partial', 'completed', 'closed']


def _escape(value: str | None) -> str:
    return html.escape(value or '', quote=True)


def _layout(title: str, body: str) -> str:
    return f"""<!doctype html>
<html><head><meta charset='utf-8'><title>{_escape(title)}</title>
<style>
body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #0f172a; }}
a {{ color: #0f62fe; text-decoration: none; }}
a:hover {{ text-decoration: underline; }}
nav {{ margin-bottom: 1rem; display:flex; gap:1rem; flex-wrap: wrap; }}
.card {{ border:1px solid #ddd; border-radius: 12px; padding:1rem; margin: 1rem 0; }}
.cards {{ display:flex; gap:1rem; flex-wrap:wrap; }}
.grid {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; }}
label {{ display:block; font-weight:600; margin-top:0.7rem; }}
input[type=text], input[type=number], textarea, select {{ width:100%; padding:0.65rem; border:1px solid #cbd5e1; border-radius:8px; box-sizing:border-box; }}
textarea {{ min-height: 120px; }}
button {{ margin-top: 1rem; padding:0.7rem 1rem; border:0; border-radius:10px; background:#0f62fe; color:white; cursor:pointer; }}
table {{ border-collapse: collapse; width:100%; }}
th, td {{ padding:0.6rem; border-bottom:1px solid #e2e8f0; text-align:left; vertical-align: top; }}
.muted {{ color:#475569; }}
.success {{ background:#ecfdf5; border:1px solid #86efac; padding:0.8rem; border-radius:10px; margin: 1rem 0; }}
</style></head><body>
<nav>
  <a href='/'>Dashboard</a>
  <a href='/requests'>Requests</a>
  <a href='/requests/new'>New request</a>
  <a href='/authorities'>Authorities</a>
  <a href='/authorities/import'>Import authorities</a>
</nav>
{body}
</body></html>"""


def _status_options(current: str) -> str:
    return ''.join(
        f"<option value='{_escape(status)}'{' selected' if status == current else ''}>{_escape(status)}</option>"
        for status in STATUSES
    )


def _authority_options(db_path: str, current: str = '') -> str:
    rows = query_all(db_path, 'SELECT slug, name FROM authorities ORDER BY name')
    return ''.join(
        f"<option value='{_escape(r['slug'])}'{' selected' if r['slug'] == current else ''}>{_escape(r['name'])} ({_escape(r['slug'])})</option>"
        for r in rows
    )


def _render_dashboard(db_path: str, flash: str = '') -> str:
    payload = dashboard_payload(db_path)
    items = payload['items'][:10]
    flash_html = f"<div class='success'>{_escape(flash)}</div>" if flash else ''
    rows = ''.join(
        f"<tr><td>{i['id']}</td><td>{_escape(i['authority_slug'])}</td><td><a href='/requests/{i['id']}'>{_escape(i['title'])}</a></td><td>{_escape(i['status'])}</td><td>{_escape(str(i.get('fyi_request_id') or ''))}</td></tr>"
        for i in items
    )
    body = f"""
    <h1>FYI Request System</h1>
    {flash_html}
    <div class='cards'>
      <div class='card'><div>Total tracked</div><strong>{payload['summary']['total']}</strong></div>
      <div class='card'><div>Needs attention</div><strong>{payload['summary']['attention']}</strong></div>
      <div class='card'><div>Action now</div><strong>{payload['summary'].get('action_now', 0)}</strong></div>
      <div class='card'><div>Authorities</div><strong>{payload['summary']['authorities']}</strong></div>
      <div class='card'><div>Recent updates (7d)</div><strong>{payload['summary']['recent_updates']}</strong></div>
    </div>
    <div class='grid'>
      <div class='card'>
        <h2>Quick actions</h2>
        <p><a href='/requests/new'>Create a tracked request</a></p>
        <p><a href='/authorities/import'>Import authority CSV</a></p>
        <p><a href='/api/dashboard'>View dashboard JSON</a></p>
        <p><a href='/requests?priority=now'>Review action-now queue</a></p>
      </div>
      <div class='card'>
        <h2>Recently tracked</h2>
        <table><thead><tr><th>ID</th><th>Authority</th><th>Title</th><th>Status</th><th>FYI</th></tr></thead><tbody>{rows}</tbody></table>
      </div>
    </div>
    """
    return _layout('FYI Request System', body)


def _render_requests(db_path: str, q: str = '', flash: str = '', priority: str = '') -> str:
    params = []
    sql = 'SELECT id, authority_slug, title, status, fyi_request_id, tags, updated_at FROM tracked_requests'
    if q:
        sql += ' WHERE lower(title) LIKE ? OR lower(authority_slug) LIKE ? OR lower(tags) LIKE ?'
        wildcard = f"%{q.lower()}%"
        params = [wildcard, wildcard, wildcard]
    sql += ' ORDER BY updated_at DESC, id DESC'
    rows = query_all(db_path, sql, params)
    if priority:
        wanted = priority.strip().lower()
        from .reporting import response_analysis
        rows = [r for r in rows if response_analysis(db_path, int(r['id']))['priority'] == wanted]
    rows_html_parts = []
    for r in rows:
        rows_html_parts.append(
            f"<tr><td>{r['id']}</td><td>{_escape(r['authority_slug'])}</td><td><a href='/requests/{r['id']}'>{_escape(r['title'])}</a></td>"
            f"<td><form method='post' action='/requests/{r['id']}/status' style='display:flex;gap:0.4rem;align-items:center;'><select name='status'>{_status_options(r['status'])}</select><button type='submit'>Save</button></form></td>"
            f"<td>{_escape(str(r['fyi_request_id'] or ''))}</td><td>{_escape(r['tags'] or '')}</td><td>{_escape(r['updated_at'] or '')}</td><td><a href='/requests/{r['id']}'>View</a> · <a href='/requests/{r['id']}/edit'>Edit</a> · <a href='/requests/{r['id']}/timeline'>Timeline</a></td></tr>"
        )
    rows_html = ''.join(rows_html_parts) or "<tr><td colspan='8' class='muted'>No tracked requests yet.</td></tr>"
    flash_html = f"<div class='success'>{_escape(flash)}</div>" if flash else ''
    body = f"""
    <h1>Tracked requests</h1>
    {flash_html}
    <form method='get' action='/requests' class='card'>
      <label for='q'>Search</label>
      <input type='text' id='q' name='q' value='{_escape(q)}' placeholder='title, authority, tag'>
      <label for='priority'>Priority</label>
      <select id='priority' name='priority'><option value=''>all</option><option value='now'{' selected' if priority=='now' else ''}>now</option><option value='soon'{' selected' if priority=='soon' else ''}>soon</option></select>
      <button type='submit'>Search</button>
    </form>
    <div class='card'>
      <table>
        <thead><tr><th>ID</th><th>Authority</th><th>Title</th><th>Status</th><th>FYI</th><th>Tags</th><th>Updated</th><th>Actions</th></tr></thead>
        <tbody>{rows_html}</tbody>
      </table>
    </div>
    """
    return _layout('Tracked requests', body)


def _render_request_form(db_path: str, request_row=None, flash: str = '') -> str:
    editing = request_row is not None
    title = request_row['title'] if editing else ''
    authority_slug = request_row['authority_slug'] if editing else ''
    body_val = request_row['body'] if editing else ''
    tags = request_row['tags'] if editing else ''
    status = request_row['status'] if editing else 'draft'
    fyi_request_id = request_row['fyi_request_id'] if editing else ''
    fyi_url = request_row['fyi_url'] if editing else ''
    action = f"/requests/{request_row['id']}/update" if editing else '/requests/create'
    legend = f"Edit tracked request #{request_row['id']}" if editing else 'Create tracked request'
    flash_html = f"<div class='success'>{_escape(flash)}</div>" if flash else ''
    preview = ''
    if authority_slug and title and body_val:
        preview_url = build_prefilled_url(authority_slug, title, body_val, tags=[t.strip() for t in tags.split(',') if t.strip()])
        preview = f"<p><a href='{_escape(preview_url)}' target='_blank' rel='noreferrer'>Open FYI prefilled draft</a></p>"
    body = f"""
    <h1>{legend}</h1>
    {flash_html}
    <form method='post' action='{action}' class='card'>
      <label for='authority_slug'>Authority</label>
      <select id='authority_slug' name='authority_slug'>{_authority_options(db_path, authority_slug)}</select>
      <label for='title'>Title</label>
      <input type='text' id='title' name='title' value='{_escape(title)}' required>
      <label for='body'>Body</label>
      <textarea id='body' name='body' required>{_escape(body_val)}</textarea>
      <label for='tags'>Tags (comma-separated)</label>
      <input type='text' id='tags' name='tags' value='{_escape(tags)}'>
      <label for='status'>Status</label>
      <select id='status' name='status'>{_status_options(status)}</select>
      <label for='fyi_request_id'>FYI request ID</label>
      <input type='number' id='fyi_request_id' name='fyi_request_id' value='{_escape(str(fyi_request_id or ''))}'>
      <label for='fyi_url'>FYI request URL</label>
      <input type='text' id='fyi_url' name='fyi_url' value='{_escape(fyi_url or '')}'>
      <button type='submit'>{'Save changes' if editing else 'Create request'}</button>
    </form>
    <div class='card'>
      <h2>FYI draft preview</h2>
      <p class='muted'>This uses FYI's documented prefilled request URL pattern.</p>
      {preview}
    </div>
    """
    return _layout(legend, body)


def _render_request_detail(db_path: str, request_id: int, flash: str = '') -> str:
    row = get_tracked_request(db_path, request_id)
    if not row:
        return _layout('Not found', '<h1>Request not found</h1>')
    flash_html = f"<div class='success'>{_escape(flash)}</div>" if flash else ''
    snapshot = latest_snapshot_summary(db_path, row['fyi_request_id'])
    preview = ''
    if row['authority_slug'] and row['title'] and row['body']:
        preview_url = build_prefilled_url(row['authority_slug'], row['title'], row['body'], tags=[t.strip() for t in (row['tags'] or '').split(',') if t.strip()])
        preview = f"<a href='{_escape(preview_url)}' target='_blank' rel='noreferrer'>Open FYI prefilled draft</a>"
    fyi_link = ''
    if row['fyi_url']:
        fyi_link = f"<a href='{_escape(row['fyi_url'])}' target='_blank' rel='noreferrer'>Open tracked FYI URL</a>"
    snapshot_html = "<p class='muted'>No FYI request snapshot stored yet.</p>"
    attachments_html = "<li class='muted'>No attachments detected.</li>"
    events_html = "<li class='muted'>No snapshot events detected.</li>"
    follow_up = suggest_follow_up(db_path, request_id)
    followup_html = f"<p><strong>{_escape(follow_up['subject'])}</strong></p><pre>{_escape(follow_up['body'])}</pre><p class='muted'>{_escape(follow_up['rationale'])}</p>"
    analysis = response_analysis(db_path, request_id)
    analysis_html = f"<p><strong>Tracked status:</strong> {_escape(str(analysis.get('tracked_status') or ''))}<br><strong>Snapshot state:</strong> {_escape(str(analysis.get('snapshot_state') or ''))}<br><strong>Attachments:</strong> {_escape(str(analysis.get('attachments_count') or 0))}<br><strong>Events:</strong> {_escape(str(analysis.get('events_count') or 0))}</p><p class='muted'>{_escape(analysis.get('recommendation') or '')}</p>"
    variants = follow_up_variants(db_path, request_id)
    variants_html = ''.join(
        f"<li><strong>{_escape(v.get('strategy') or '')}</strong>: {_escape(v.get('why') or '')}<br><details><summary>{_escape(v.get('subject') or '')}</summary><pre>{_escape(v.get('body') or '')}</pre></details></li>"
        for v in variants.get('variants', [])
    ) or "<li class='muted'>No alternative variants generated.</li>"
    pack = follow_up_pack(db_path, request_id)
    pack_cards = []
    for item in pack.get('items', [])[:9]:
        pack_cards.append(f"<li><strong>{_escape(item.get('strategy') or '')}</strong> / {_escape(item.get('tone') or '')}<br><details><summary>{_escape(item.get('subject') or '')}</summary><pre>{_escape(item.get('body') or '')}</pre></details></li>")
    pack_html = ''.join(pack_cards) or "<li class='muted'>No strategy-and-tone pack generated.</li>"
    if snapshot:
        attachments_html = ''.join(
            f"<li><a href='{_escape(a.get('url') or '')}' target='_blank' rel='noreferrer'>{_escape(a.get('name') or 'attachment')}</a> <span class='muted'>{_escape(a.get('content_type') or '')}</span></li>"
            for a in snapshot.get('attachments', [])[:20]
        ) or attachments_html
        events_html = ''.join(
            f"<li><strong>{_escape(e.get('title') or 'event')}</strong> <span class='muted'>{_escape(e.get('created_at') or '')}</span><br>{_escape(e.get('detail') or '')}</li>"
            for e in snapshot.get('events', [])[:20]
        ) or events_html
        snapshot_html = f"""
        <p><strong>Latest snapshot:</strong> {_escape(snapshot.get('fetched_at') or '')}</p>
        <p><strong>State:</strong> {_escape(snapshot.get('described_state') or '')}</p>
        <p><strong>Attachments detected:</strong> {snapshot.get('attachments_count', 0)}<br><strong>Events detected:</strong> {snapshot.get('events_count', 0)}</p>
        <p><a href='{_escape(snapshot.get('source_url') or '')}' target='_blank' rel='noreferrer'>Open snapshot source URL</a></p>
        """
    body = f"""
    <h1>Request #{request_id}</h1>
    {flash_html}
    <div class='grid'>
      <div class='card'>
        <h2>Tracked request</h2>
        <p><strong>Title</strong><br>{_escape(row['title'])}</p>
        <p><strong>Authority</strong><br>{_escape(row['authority_slug'])}</p>
        <p><strong>Status</strong><br>{_escape(row['status'])}</p>
        <p><strong>Tags</strong><br>{_escape(row['tags'] or '')}</p>
        <p><strong>FYI request ID</strong><br>{_escape(str(row['fyi_request_id'] or ''))}</p>
        <p><strong>Body</strong><br>{_escape(row['body'])}</p>
        <p>{preview}</p>
        <p>{fyi_link}</p>
        <p><a href='/requests/{request_id}/edit'>Edit tracked request</a> · <a href='/requests/{request_id}/timeline'>Timeline</a></p>
      </div>
      <div class='card'>
        <h2>Latest FYI snapshot</h2>
        {snapshot_html}
      </div>
    </div>
    <div class='grid'>
      <div class='card'>
        <h2>Attachments</h2>
        <ul>{attachments_html}</ul>
      </div>
      <div class='card'>
        <h2>Snapshot events</h2>
        <ul>{events_html}</ul>
      </div>
    </div>
    <div class='grid'>
      <div class='card'>
        <h2>Response analysis</h2>
        {analysis_html}
      </div>
      <div class='card'>
        <h2>Suggested follow-up draft</h2>
        {followup_html}
      </div>
    </div>
    <div class='card'>
      <h2>Alternative follow-up variants</h2>
      <ul>{variants_html}</ul>
    </div>
    <div class='card'>
      <h2>Strategy and tone pack</h2>
      <ul>{pack_html}</ul>
    </div>
    """
    return _layout(f'Request #{request_id}', body)


def _render_authorities(db_path: str, q: str = '', flash: str = '') -> str:
    params = []
    sql = 'SELECT slug, name, url FROM authorities'
    if q:
        sql += ' WHERE lower(name) LIKE ? OR lower(slug) LIKE ?'
        wildcard = f"%{q.lower()}%"
        params = [wildcard, wildcard]
    sql += ' ORDER BY name'
    rows = query_all(db_path, sql, params)
    links = []
    for r in rows:
        link_html = ''
        if r['url']:
            safe_url = _escape(r['url'])
            link_html = f"<a href='{safe_url}' target='_blank' rel='noreferrer'>link</a>"
        links.append(f"<tr><td>{_escape(r['slug'])}</td><td>{_escape(r['name'])}</td><td>{link_html}</td></tr>")
    rows_html = ''.join(links) or "<tr><td colspan='3' class='muted'>No authorities loaded yet.</td></tr>"
    flash_html = f"<div class='success'>{_escape(flash)}</div>" if flash else ''
    body = f"""
    <h1>Authorities</h1>
    {flash_html}
    <form method='get' action='/authorities' class='card'>
      <label for='q'>Search</label>
      <input type='text' id='q' name='q' value='{_escape(q)}' placeholder='authority name or slug'>
      <button type='submit'>Search</button>
    </form>
    <div class='card'>
      <table>
        <thead><tr><th>Slug</th><th>Name</th><th>URL</th></tr></thead>
        <tbody>{rows_html}</tbody>
      </table>
    </div>
    """
    return _layout('Authorities', body)


def _render_import_form(message: str = '') -> str:
    message_html = f"<div class='success'>{_escape(message)}</div>" if message else ''
    body = f"""
    <h1>Import authorities</h1>
    {message_html}
    <div class='card'>
      <p class='muted'>Upload a CSV with columns such as <code>url_name</code>/<code>slug</code>, <code>name</code>, and optional <code>url</code>.</p>
      <form method='post' action='/authorities/import' enctype='multipart/form-data'>
        <label for='csv_file'>CSV file</label>
        <input type='file' id='csv_file' name='csv_file' accept='.csv,text/csv' required>
        <button type='submit'>Import</button>
      </form>
    </div>
    """
    return _layout('Import authorities', body)



def _render_timeline(db_path: str, request_id: int, flash: str = '') -> str:
    row = get_tracked_request(db_path, request_id)
    if not row:
        return _layout('Not found', '<h1>Request not found</h1>')
    events = request_timeline(db_path, request_id)
    items = []
    for ev in events:
        items.append(f"<tr><td>{_escape(ev['ts'] or '')}</td><td>{_escape(ev['kind'])}</td><td>{_escape(ev['title'])}</td><td>{_escape(ev['detail'] or '')}</td></tr>")
    rows_html = ''.join(items) or "<tr><td colspan='4' class='muted'>No timeline events yet.</td></tr>"
    flash_html = f"<div class='success'>{_escape(flash)}</div>" if flash else ''
    body = f"""
    <h1>Timeline for request #{request_id}</h1>
    {flash_html}
    <div class='card'><p><strong>{_escape(row['title'])}</strong><br><span class='muted'>{_escape(row['authority_slug'])} · {_escape(row['status'])}</span></p><p><a href='/requests/{request_id}'>Back to request</a></p></div>
    <div class='card'>
      <table>
        <thead><tr><th>Timestamp</th><th>Type</th><th>Title</th><th>Detail</th></tr></thead>
        <tbody>{rows_html}</tbody>
      </table>
    </div>
    """
    return _layout(f'Timeline #{request_id}', body)

def _redirect(handler, location: str):
    handler.send_response(303)
    handler.send_header('Location', location)
    handler.end_headers()


def _parse_multipart(handler, content_type: str, body: bytes):
    marker = 'boundary='
    if marker not in content_type:
        raise ValueError('Missing multipart boundary')
    boundary = content_type.split(marker, 1)[1].strip().strip('"')
    boundary_bytes = ('--' + boundary).encode('utf-8')
    result: dict[str, object] = {}
    parts = body.split(boundary_bytes)
    for part in parts:
        part = part.strip()
        if not part or part == b'--':
            continue
        if part.startswith(b'--'):
            part = part[2:]
        if b'\r\n\r\n' not in part:
            continue
        header_block, content = part.split(b'\r\n\r\n', 1)
        content = content.rstrip(b'\r\n')
        headers = header_block.decode('utf-8', errors='replace').split('\r\n')
        disposition = next((h for h in headers if h.lower().startswith('content-disposition:')), '')
        if 'name=' not in disposition:
            continue
        segments = [seg.strip() for seg in disposition.split(';')]
        attrs = {}
        for seg in segments[1:]:
            if '=' in seg:
                k, v = seg.split('=', 1)
                attrs[k.strip().lower()] = v.strip().strip('"')
        name = attrs.get('name')
        filename = attrs.get('filename')
        if not name:
            continue
        if filename:
            result[name] = {'filename': filename, 'content': content}
        else:
            result[name] = content.decode('utf-8', errors='replace')
    return result


def _parse_post_fields(handler):
    content_type = handler.headers.get('Content-Type', '')
    length = int(handler.headers.get('Content-Length', '0'))
    body = handler.rfile.read(length)
    if content_type.startswith('application/json'):
        return json.loads(body.decode('utf-8')) if body else {}
    if content_type.startswith('multipart/form-data'):
        return _parse_multipart(handler, content_type, body)
    parsed = parse_qs(body.decode('utf-8'), keep_blank_values=True)
    return {k: v[-1] for k, v in parsed.items()}


def make_handler(db_path: str):
    class Handler(BaseHTTPRequestHandler):
        def _json(self, payload: dict, status: int = 200):
            data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        def _html(self, html_text: str, status: int = 200):
            data = html_text.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        def do_GET(self):
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            flash = (qs.get('flash') or [''])[0]
            if parsed.path == '/api/dashboard':
                return self._json(dashboard_payload(db_path))
            if parsed.path == '/':
                return self._html(_render_dashboard(db_path, flash=flash))
            if parsed.path == '/requests':
                return self._html(_render_requests(db_path, q=(qs.get('q') or [''])[0], flash=flash))
            if parsed.path == '/requests/new':
                return self._html(_render_request_form(db_path, flash=flash))
            if parsed.path.startswith('/requests/') and parsed.path.endswith('/timeline'):
                try:
                    request_id = int(parsed.path.strip('/').split('/')[1])
                except (ValueError, IndexError):
                    return self._json({'error': 'not found'}, status=404)
                return self._html(_render_timeline(db_path, request_id, flash=flash))
            if parsed.path.startswith('/requests/') and not parsed.path.endswith('/update') and not parsed.path.endswith('/status'):
                try:
                    request_id = int(parsed.path.strip('/').split('/')[1])
                except (ValueError, IndexError):
                    return self._json({'error': 'not found'}, status=404)
                row = get_tracked_request(db_path, request_id)
                if not row:
                    return self._json({'error': 'not found'}, status=404)
                return self._html(_render_request_form(db_path, request_row=row, flash=flash))
            if parsed.path == '/authorities':
                return self._html(_render_authorities(db_path, q=(qs.get('q') or [''])[0], flash=flash))
            if parsed.path == '/authorities/import':
                return self._html(_render_import_form(message=flash))
            return self._json({'error': 'not found'}, status=404)
        def do_POST(self):
            parsed = urlparse(self.path)
            if parsed.path == '/api/draft-url':
                payload = _parse_post_fields(self)
                tags = payload.get('tags', [])
                if isinstance(tags, str):
                    tags = [t.strip() for t in tags.split(',') if t.strip()]
                url = build_prefilled_url(payload.get('authority_slug', ''), payload.get('title', ''), payload.get('body', ''), tags=tags)
                return self._json({'url': url})
            if parsed.path == '/requests/create':
                form = _parse_post_fields(self)
                request_id = insert_tracked_request(
                    db_path,
                    authority_slug=str(form.get('authority_slug', '')).strip(),
                    title=str(form.get('title', '')).strip(),
                    body=str(form.get('body', '')).strip(),
                    tags=str(form.get('tags', '')).strip(),
                    status=str(form.get('status', 'draft')).strip() or 'draft',
                    fyi_request_id=int(form['fyi_request_id']) if str(form.get('fyi_request_id', '')).strip() else None,
                    fyi_url=str(form.get('fyi_url', '')).strip() or None,
                )
                return _redirect(self, f'/requests/{request_id}?flash=Saved')
            if parsed.path.startswith('/requests/') and parsed.path.endswith('/status'):
                parts = parsed.path.strip('/').split('/')
                try:
                    request_id = int(parts[1])
                except (ValueError, IndexError):
                    return self._json({'error': 'not found'}, status=404)
                form = _parse_post_fields(self)
                update_request_status(db_path, request_id, str(form.get('status', 'draft')).strip() or 'draft')
                return _redirect(self, f'/requests?flash=Status+updated')
            if parsed.path.startswith('/requests/') and parsed.path.endswith('/update'):
                parts = parsed.path.strip('/').split('/')
                try:
                    request_id = int(parts[1])
                except (ValueError, IndexError):
                    return self._json({'error': 'not found'}, status=404)
                form = _parse_post_fields(self)
                update_tracked_request(
                    db_path,
                    request_id,
                    authority_slug=str(form.get('authority_slug', '')).strip(),
                    title=str(form.get('title', '')).strip(),
                    body=str(form.get('body', '')).strip(),
                    tags=str(form.get('tags', '')).strip(),
                    status=str(form.get('status', 'draft')).strip() or 'draft',
                    fyi_request_id=int(form['fyi_request_id']) if str(form.get('fyi_request_id', '')).strip() else None,
                    fyi_url=str(form.get('fyi_url', '')).strip() or None,
                )
                return _redirect(self, f'/requests/{request_id}/edit?flash=Updated')
            if parsed.path == '/authorities/import':
                form = _parse_post_fields(self)
                field = form.get('csv_file')
                if not isinstance(field, dict):
                    return self._html(_render_import_form('No CSV uploaded.'), status=400)
                upload_dir = Path('.uploads')
                upload_dir.mkdir(exist_ok=True)
                filename = Path(str(field.get('filename') or 'authorities.csv')).name
                dest = upload_dir / filename
                dest.write_bytes(bytes(field.get('content') or b''))
                count = import_authorities_csv(dest, db_path=db_path)
                return _redirect(self, f'/authorities?flash=Imported+{count}+authorities')
            return self._json({'error': 'not found'}, status=404)
        def log_message(self, fmt, *args):
            return
    return Handler


def serve(host: str = '127.0.0.1', port: int = 8000, db_path: str = 'fyi_system.db'):
    init_db(db_path)
    server = ThreadingHTTPServer((host, port), make_handler(db_path))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
