from __future__ import annotations

import json
from pathlib import Path

from fyi_system.db import (
    connect,
    get_latest_feed_snapshot,
    insert_feed_events,
    insert_feed_snapshot,
    insert_request,
    list_stalled_or_overdue,
    upsert_authorities,
    upsert_request_page,
    update_request_monitoring_fields,
)
from fyi_system.fetch import parse_request_page, request_json_url
from fyi_system.models import Authority, FeedEntry, RequestPage, RequestRecord
from fyi_system.reporting import render_handover_markdown, write_attention_report
from fyi_system.storage import diff_feed_entries


def test_request_json_url_adds_suffix() -> None:
    assert request_json_url('https://fyi.org.nz/request/123-example') == 'https://fyi.org.nz/request/123-example.json'
    assert request_json_url('https://fyi.org.nz/request/123-example?unfold=1') == 'https://fyi.org.nz/request/123-example.json?unfold=1'


def test_parse_request_page_handles_nested_authority() -> None:
    payload = {
        'title': 'Example request',
        'status': 'waiting_response',
        'public_body': {'name': 'Ministry of Testing'},
        'date_response_required_by': '2026-03-31',
        'updated_at': '2026-03-10T12:00:00Z',
    }
    page = parse_request_page('https://fyi.org.nz/request/1-example', payload)
    assert page.authority_name == 'Ministry of Testing'
    assert page.due_date == '2026-03-31'
    assert page.last_public_update_at == '2026-03-10T12:00:00Z'


def test_feed_snapshot_diff_and_db_roundtrip(tmp_path: Path) -> None:
    db_path = tmp_path / 'fyi.db'
    conn = connect(db_path)
    previous = [FeedEntry(title='Old', link='https://example.com/old')]
    current = [FeedEntry(title='Old', link='https://example.com/old'), FeedEntry(title='New', link='https://example.com/new')]
    insert_feed_snapshot(conn, 'https://fyi.org.nz/search/test/feed', previous)
    latest = get_latest_feed_snapshot(conn, 'https://fyi.org.nz/search/test/feed')
    assert latest is not None
    diff = diff_feed_entries('https://fyi.org.nz/search/test/feed', previous, current)
    assert diff.added_links == ['https://example.com/new']


def test_attention_report_and_handover(tmp_path: Path) -> None:
    db_path = tmp_path / 'fyi.db'
    conn = connect(db_path)
    upsert_authorities(conn, [Authority(name='Authority', slug='authority')])
    request_id = insert_request(
        conn,
        RequestRecord(
            title='Test request',
            authority_slug='authority',
            request_url='https://fyi.org.nz/request/1-test',
            status='waiting_response',
        ),
    )
    page = RequestPage(
        url='https://fyi.org.nz/request/1-test',
        title='Test request',
        status='waiting_response',
        due_date='2026-03-01',
        last_public_update_at='2026-01-15T12:00:00Z',
        raw={'title': 'Test request'},
    )
    upsert_request_page(conn, request_id, page)
    update_request_monitoring_fields(
        conn,
        request_id,
        status='waiting_response',
        due_date='2026-03-01',
        last_public_update_at='2026-01-15T12:00:00Z',
    )
    rows = list_stalled_or_overdue(conn, as_of_date='2026-03-08', stale_days=30)
    assert len(rows) == 1
    report_path = tmp_path / 'attention.json'
    count = write_attention_report(conn, report_path, as_of_date='2026-03-08', stale_days=30)
    assert count == 1
    payload = json.loads(report_path.read_text(encoding='utf-8'))
    assert payload[0]['attention_state'] in {'overdue', 'stalled'}
    handover = render_handover_markdown(conn, as_of_date='2026-03-08', stale_days=30)
    assert 'Test request' in handover
