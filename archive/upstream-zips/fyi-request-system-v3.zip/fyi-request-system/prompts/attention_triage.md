# Attention triage prompt

Review the attention report JSON and produce:
- a ranked queue of items to act on first
- concise reasons for priority
- a suggested next action for each item
- a note on whether escalation, clarification, or patience is most appropriate
