# phase-3-operator

Purpose: run the end-to-end phase 3 workflow.

Steps:
1. ingest relevant FYI feeds
2. fetch request-page JSON for active requests
3. generate attention report
4. generate handover markdown
5. update the relevant Conductor track notes
