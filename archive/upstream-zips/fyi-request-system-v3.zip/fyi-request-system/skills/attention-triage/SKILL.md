# attention-triage

Purpose: turn the attention report into a practical action queue.

Inputs:
- `outputs/attention-report.json`
- `outputs/handover.md`

Outputs:
- triage summary
- ranked next actions
