#!/usr/bin/env bash
set -euo pipefail

fyi-system init-db
fyi-system import-authorities data/all-authorities.csv
fyi-system register-request auckland_council "Service metrics request" "Please provide service volumes by month for 2025 and 2026 to date." --tags "topic:metrics domain:service"
fyi-system ingest-feed "https://fyi.org.nz/search/service/feed"
fyi-system fetch-request-page 1
fyi-system attention-report --output outputs/attention-report.json
fyi-system handover --output outputs/handover.md
