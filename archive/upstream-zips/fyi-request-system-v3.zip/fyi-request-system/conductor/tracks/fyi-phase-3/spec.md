# FYI phase 3 spec

## Objective

Extend the local FYI request system with active monitoring, snapshot diffing, request-page normalization, overdue/stalled detection, and automated handover generation.

## Acceptance criteria

- Feed snapshots are persisted.
- New feed items can be distinguished from previous polls.
- Request pages can be fetched via `.json` and normalized.
- The DB stores due dates and last public updates.
- A JSON attention report can be generated.
- A markdown handover can be generated.
