# FYI phase 3 plan

1. Extend schema for request-page and snapshot data.
2. Implement feed snapshot persistence and diffing.
3. Implement request-page JSON fetch and normalization.
4. Implement stalled/overdue reporting.
5. Implement markdown handover generation.
6. Add tests.
