from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import typer
from rich import print
from rich.table import Table

from .db import (
    connect,
    get_latest_feed_snapshot,
    get_request,
    insert_feed_events,
    insert_feed_snapshot,
    insert_request,
    list_requests as db_list_requests,
    update_request_monitoring_fields,
    upsert_authorities,
    upsert_request_page,
)
from .feeds import parse_feed
from .fetch import fetch_request_page
from .fyi_urls import build_prefilled_request_url
from .models import RequestDraft, RequestRecord
from .reporting import render_handover_markdown, write_attention_report
from .storage import authorities_from_csv, diff_feed_entries, save_feed_entries

app = typer.Typer(help='FYI request system CLI')
DEFAULT_DB = Path('data/fyi.db')


def _ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


@app.command('init-db')
def init_db(db: Path = DEFAULT_DB) -> None:
    _ensure_parent(db)
    connect(db).close()
    print(f'Initialised database at {db}')


@app.command('draft-url')
def draft_url(
    authority_slug: str,
    title: str,
    body: str,
    default_letter: str = '',
    tags: str = '',
) -> None:
    draft = RequestDraft(
        authority_slug=authority_slug,
        title=title,
        body=body,
        default_letter=default_letter or None,
        tags=[tag for tag in tags.split() if tag],
    )
    print(build_prefilled_request_url(draft))


@app.command('register-request')
def register_request(
    authority_slug: str,
    title: str,
    body: str,
    db: Path = DEFAULT_DB,
    tags: str = '',
    status: str = 'draft',
    summary: str = '',
) -> None:
    _ensure_parent(db)
    draft = RequestDraft(
        authority_slug=authority_slug,
        title=title,
        body=body,
        tags=[tag for tag in tags.split() if tag],
    )
    url = build_prefilled_request_url(draft)
    conn = connect(db)
    request_id = insert_request(
        conn,
        RequestRecord(
            title=title,
            authority_slug=authority_slug,
            request_url=url,
            status=status,
            tags=[tag for tag in tags.split() if tag],
            summary=summary or None,
        ),
    )
    print(f'Registered request #{request_id}: {url}')


@app.command('import-authorities')
def import_authorities(csv_path: Path, db: Path = DEFAULT_DB) -> None:
    _ensure_parent(db)
    authorities = authorities_from_csv(csv_path)
    conn = connect(db)
    count = upsert_authorities(conn, authorities)
    print(f'Imported {count} authorities into {db}')


@app.command('list-authorities')
def list_authorities(limit: int = 20, db: Path = DEFAULT_DB) -> None:
    conn = connect(db)
    rows = conn.execute(
        'SELECT name, slug, url FROM authorities ORDER BY name LIMIT ?', (limit,)
    ).fetchall()
    table = Table(title='Authorities')
    table.add_column('Name')
    table.add_column('Slug')
    table.add_column('URL')
    for row in rows:
        table.add_row(row['name'], row['slug'], row['url'] or '')
    print(table)


@app.command('list-requests')
def list_requests(status: str = '', db: Path = DEFAULT_DB) -> None:
    conn = connect(db)
    rows = db_list_requests(conn, status=status or None)
    table = Table(title='Requests')
    table.add_column('ID')
    table.add_column('Title')
    table.add_column('Authority')
    table.add_column('Status')
    table.add_column('Due date')
    table.add_column('Last update')
    for row in rows:
        table.add_row(
            str(row['id']), row['title'], row['authority_slug'], row['status'], row['due_date'] or '', row['last_public_update_at'] or ''
        )
    print(table)


@app.command('poll-feed')
def poll_feed(url: str, output: Path | None = None) -> None:
    entries = parse_feed(url)
    if output:
        _ensure_parent(output)
        save_feed_entries(output, entries)
        print(f'Wrote {len(entries)} entries to {output}')
    else:
        print(json.dumps([entry.model_dump(mode='json') for entry in entries], indent=2))


@app.command('ingest-feed')
def ingest_feed(url: str, db: Path = DEFAULT_DB, request_id: int | None = None) -> None:
    _ensure_parent(db)
    conn = connect(db)
    previous_snapshot = get_latest_feed_snapshot(conn, url)
    entries = parse_feed(url)
    added = insert_feed_events(conn, url, entries, request_id=request_id)
    insert_feed_snapshot(conn, url, entries)
    if previous_snapshot is None:
        print(f'Ingested {len(entries)} entries from {url}; added {added} new event records; no previous snapshot.')
        return
    previous_entries = [type(entries[0]).model_validate(item) for item in json.loads(previous_snapshot['snapshot_json'])] if entries else []
    diff = diff_feed_entries(url, previous_entries, entries)
    print(json.dumps(diff.model_dump(mode='json'), indent=2))


@app.command('fetch-request-page')
def fetch_request_page_command(request_id: int, db: Path = DEFAULT_DB) -> None:
    _ensure_parent(db)
    conn = connect(db)
    row = get_request(conn, request_id)
    if row is None:
        raise typer.BadParameter(f'Unknown request id: {request_id}')
    if not row['request_url']:
        raise typer.BadParameter(f'Request #{request_id} does not have a request_url')
    page = fetch_request_page(row['request_url'])
    upsert_request_page(conn, request_id, page)
    update_request_monitoring_fields(
        conn,
        request_id,
        status=page.status or row['status'],
        due_date=page.due_date,
        last_public_update_at=page.last_public_update_at,
    )
    print(json.dumps(page.model_dump(mode='json'), indent=2, ensure_ascii=False))


@app.command('attention-report')
def attention_report(
    output: Path = Path('outputs/attention-report.json'),
    db: Path = DEFAULT_DB,
    as_of_date: str = typer.Option(default_factory=lambda: date.today().isoformat()),
    stale_days: int = 30,
) -> None:
    _ensure_parent(output)
    conn = connect(db)
    count = write_attention_report(conn, output, as_of_date=as_of_date, stale_days=stale_days)
    print(f'Wrote {count} attention items to {output}')


@app.command('handover')
def handover(
    output: Path = Path('outputs/handover.md'),
    db: Path = DEFAULT_DB,
    as_of_date: str = typer.Option(default_factory=lambda: date.today().isoformat()),
    stale_days: int = 30,
) -> None:
    _ensure_parent(output)
    conn = connect(db)
    markdown = render_handover_markdown(conn, as_of_date=as_of_date, stale_days=stale_days)
    output.write_text(markdown, encoding='utf-8')
    print(f'Wrote handover to {output}')


if __name__ == '__main__':
    app()
