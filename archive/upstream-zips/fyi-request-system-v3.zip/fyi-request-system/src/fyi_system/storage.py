from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable

from .models import Authority, FeedEntry, SnapshotDiff


def authorities_from_csv(path: Path) -> list[Authority]:
    with path.open('r', encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        results: list[Authority] = []
        for row in reader:
            name = row.get('name') or row.get('authority_name') or row.get('Authority') or ''
            slug = row.get('url_name') or row.get('slug') or row.get('authority_slug') or ''
            if not name or not slug:
                continue
            results.append(
                Authority(
                    name=name.strip(),
                    slug=slug.strip(),
                    url=(row.get('request_email') or row.get('url') or '').strip() or None,
                    notes=json.dumps(row, ensure_ascii=False),
                )
            )
    return results


def save_feed_entries(path: Path, entries: Iterable[FeedEntry]) -> None:
    payload = [entry.model_dump(mode='json') for entry in entries]
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')


def load_feed_entries(path: Path) -> list[FeedEntry]:
    payload = json.loads(path.read_text(encoding='utf-8'))
    return [FeedEntry.model_validate(item) for item in payload]


def diff_feed_entries(source_url: str, previous: Iterable[FeedEntry], current: Iterable[FeedEntry]) -> SnapshotDiff:
    prev_links = {entry.link for entry in previous if entry.link}
    curr_links = {entry.link for entry in current if entry.link}
    return SnapshotDiff(
        source_url=source_url,
        previous_count=len(prev_links),
        current_count=len(curr_links),
        added_links=sorted(curr_links - prev_links),
        removed_links=sorted(prev_links - curr_links),
    )
