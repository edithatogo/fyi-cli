from __future__ import annotations

import json
from pathlib import Path

from .db import list_stalled_or_overdue


def write_attention_report(db_conn, output: Path, *, as_of_date: str, stale_days: int = 30) -> int:
    rows = list_stalled_or_overdue(db_conn, as_of_date=as_of_date, stale_days=stale_days)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = [dict(row) for row in rows]
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return len(payload)


def render_handover_markdown(db_conn, *, as_of_date: str, stale_days: int = 30) -> str:
    rows = list_stalled_or_overdue(db_conn, as_of_date=as_of_date, stale_days=stale_days)
    lines = [
        '# FYI Request Handover',
        '',
        f'- As of date: {as_of_date}',
        f'- Stale threshold (days): {stale_days}',
        f'- Items needing attention: {len(rows)}',
        '',
        '## Attention queue',
        '',
    ]
    if not rows:
        lines.append('No overdue or stalled requests detected.')
        return '\n'.join(lines) + '\n'
    for row in rows:
        lines.extend([
            f"### #{row['id']} — {row['title']}",
            f"- Authority slug: {row['authority_slug']}",
            f"- Status: {row['status']}",
            f"- Attention state: {row['attention_state']}",
            f"- Due date: {row['due_date'] or 'n/a'}",
            f"- Last public update: {row['last_public_update_at'] or 'n/a'}",
            '',
        ])
    return '\n'.join(lines) + '\n'
