from __future__ import annotations

from typing import Any

import httpx

from .models import RequestPage


def fetch_json(url: str, timeout: float = 20.0) -> dict[str, Any]:
    with httpx.Client(follow_redirects=True, timeout=timeout, headers={"User-Agent": "fyi-request-system/0.3"}) as client:
        response = client.get(url)
        response.raise_for_status()
        return response.json()


def request_json_url(url: str) -> str:
    if url.endswith('.json'):
        return url
    if '?' in url:
        base, query = url.split('?', 1)
        return f'{base}.json?{query}'
    return f'{url}.json'


def parse_request_page(url: str, payload: dict[str, Any]) -> RequestPage:
    return RequestPage(
        url=url,
        title=_pick(payload, 'title', 'display_title'),
        status=_pick(payload, 'status'),
        described_state=_pick(payload, 'described_state', 'state', 'awaiting_description'),
        authority_name=_pick_nested(payload, [('public_body', 'name'), ('authority', 'name')]),
        requested_date=_pick(payload, 'created_at', 'requested_date'),
        due_date=_pick(payload, 'date_response_required_by', 'due_date'),
        last_public_update_at=_pick(payload, 'updated_at', 'last_public_response_at', 'last_event_formatted'),
        raw=payload,
    )


def fetch_request_page(url: str, timeout: float = 20.0) -> RequestPage:
    json_url = request_json_url(url)
    payload = fetch_json(json_url, timeout=timeout)
    return parse_request_page(url, payload)


def _pick(payload: dict[str, Any], *keys: str) -> str | None:
    for key in keys:
        value = payload.get(key)
        if value not in (None, ''):
            return str(value)
    return None


def _pick_nested(payload: dict[str, Any], paths: list[tuple[str, str]]) -> str | None:
    for path in paths:
        current: Any = payload
        for part in path:
            if not isinstance(current, dict) or part not in current:
                current = None
                break
            current = current[part]
        if current not in (None, ''):
            return str(current)
    return None
