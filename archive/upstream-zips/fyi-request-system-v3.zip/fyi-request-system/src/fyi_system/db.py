from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Iterable

from .models import Authority, FeedEntry, RequestPage, RequestRecord

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS authorities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    url TEXT,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    authority_slug TEXT NOT NULL,
    request_url TEXT,
    status TEXT NOT NULL DEFAULT 'draft',
    tags TEXT NOT NULL DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    summary TEXT,
    due_date TEXT,
    last_public_update_at TEXT,
    last_checked_at TEXT,
    FOREIGN KEY (authority_slug) REFERENCES authorities(slug)
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id INTEGER,
    source_url TEXT NOT NULL,
    event_id TEXT,
    title TEXT NOT NULL,
    link TEXT,
    published_at TEXT,
    payload_json TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_url, link),
    FOREIGN KEY (request_id) REFERENCES requests(id)
);

CREATE TABLE IF NOT EXISTS request_pages (
    request_id INTEGER PRIMARY KEY,
    source_url TEXT NOT NULL,
    title TEXT,
    status TEXT,
    described_state TEXT,
    authority_name TEXT,
    requested_date TEXT,
    due_date TEXT,
    last_public_update_at TEXT,
    payload_json TEXT NOT NULL,
    fetched_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES requests(id)
);

CREATE TABLE IF NOT EXISTS feed_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_url TEXT NOT NULL,
    snapshot_json TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_requests_authority_slug ON requests(authority_slug);
CREATE INDEX IF NOT EXISTS idx_events_request_id ON events(request_id);
CREATE INDEX IF NOT EXISTS idx_request_pages_due_date ON request_pages(due_date);
CREATE INDEX IF NOT EXISTS idx_feed_snapshots_source_url ON feed_snapshots(source_url);
"""


def connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def upsert_authorities(conn: sqlite3.Connection, authorities: Iterable[Authority]) -> int:
    count = 0
    for authority in authorities:
        conn.execute(
            """
            INSERT INTO authorities(name, slug, url, notes)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(slug) DO UPDATE SET
              name=excluded.name,
              url=excluded.url,
              notes=excluded.notes
            """,
            (authority.name, authority.slug, authority.url, authority.notes),
        )
        count += 1
    conn.commit()
    return count


def insert_request(conn: sqlite3.Connection, record: RequestRecord) -> int:
    cursor = conn.execute(
        """
        INSERT INTO requests(title, authority_slug, request_url, status, tags, summary)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            record.title,
            record.authority_slug,
            record.request_url,
            record.status,
            " ".join(record.tags),
            record.summary,
        ),
    )
    conn.commit()
    return int(cursor.lastrowid)


def list_requests(conn: sqlite3.Connection, status: str | None = None) -> list[sqlite3.Row]:
    if status:
        return conn.execute(
            """
            SELECT id, title, authority_slug, request_url, status, tags, due_date, last_public_update_at, last_checked_at
            FROM requests
            WHERE status = ?
            ORDER BY created_at DESC
            """,
            (status,),
        ).fetchall()
    return conn.execute(
        """
        SELECT id, title, authority_slug, request_url, status, tags, due_date, last_public_update_at, last_checked_at
        FROM requests
        ORDER BY created_at DESC
        """
    ).fetchall()


def get_request(conn: sqlite3.Connection, request_id: int) -> sqlite3.Row | None:
    return conn.execute(
        """
        SELECT id, title, authority_slug, request_url, status, tags, summary, due_date, last_public_update_at, last_checked_at
        FROM requests WHERE id = ?
        """,
        (request_id,),
    ).fetchone()


def update_request_monitoring_fields(
    conn: sqlite3.Connection,
    request_id: int,
    *,
    status: str | None = None,
    due_date: str | None = None,
    last_public_update_at: str | None = None,
) -> None:
    current = get_request(conn, request_id)
    if current is None:
        raise ValueError(f"Unknown request id: {request_id}")
    conn.execute(
        """
        UPDATE requests
        SET status = ?, due_date = ?, last_public_update_at = ?, last_checked_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            status or current['status'],
            due_date if due_date is not None else current['due_date'],
            last_public_update_at if last_public_update_at is not None else current['last_public_update_at'],
            request_id,
        ),
    )
    conn.commit()


def insert_feed_events(
    conn: sqlite3.Connection,
    source_url: str,
    entries: Iterable[FeedEntry],
    request_id: int | None = None,
) -> int:
    count = 0
    for entry in entries:
        payload_json = json.dumps(entry.model_dump(mode='json'), ensure_ascii=False)
        cursor = conn.execute(
            """
            INSERT OR IGNORE INTO events(request_id, source_url, event_id, title, link, published_at, payload_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                request_id,
                source_url,
                entry.link or entry.title,
                entry.title,
                entry.link,
                entry.published,
                payload_json,
            ),
        )
        count += int(cursor.rowcount > 0)
    conn.commit()
    return count


def insert_feed_snapshot(conn: sqlite3.Connection, source_url: str, entries: Iterable[FeedEntry]) -> int:
    payload = [entry.model_dump(mode='json') for entry in entries]
    cursor = conn.execute(
        "INSERT INTO feed_snapshots(source_url, snapshot_json) VALUES (?, ?)",
        (source_url, json.dumps(payload, ensure_ascii=False)),
    )
    conn.commit()
    return int(cursor.lastrowid)


def get_latest_feed_snapshot(conn: sqlite3.Connection, source_url: str) -> sqlite3.Row | None:
    return conn.execute(
        """
        SELECT id, source_url, snapshot_json, created_at
        FROM feed_snapshots
        WHERE source_url = ?
        ORDER BY id DESC
        LIMIT 1
        """,
        (source_url,),
    ).fetchone()


def upsert_request_page(conn: sqlite3.Connection, request_id: int, page: RequestPage) -> None:
    conn.execute(
        """
        INSERT INTO request_pages(
            request_id, source_url, title, status, described_state, authority_name,
            requested_date, due_date, last_public_update_at, payload_json, fetched_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(request_id) DO UPDATE SET
            source_url=excluded.source_url,
            title=excluded.title,
            status=excluded.status,
            described_state=excluded.described_state,
            authority_name=excluded.authority_name,
            requested_date=excluded.requested_date,
            due_date=excluded.due_date,
            last_public_update_at=excluded.last_public_update_at,
            payload_json=excluded.payload_json,
            fetched_at=CURRENT_TIMESTAMP
        """,
        (
            request_id,
            page.url,
            page.title,
            page.status,
            page.described_state,
            page.authority_name,
            page.requested_date,
            page.due_date,
            page.last_public_update_at,
            json.dumps(page.raw, ensure_ascii=False),
        ),
    )
    conn.commit()


def list_stalled_or_overdue(
    conn: sqlite3.Connection,
    *,
    as_of_date: str,
    stale_days: int = 30,
) -> list[sqlite3.Row]:
    return conn.execute(
        """
        SELECT id, title, authority_slug, status, due_date, last_public_update_at,
               CASE
                 WHEN due_date IS NOT NULL AND due_date < ? THEN 'overdue'
                 WHEN last_public_update_at IS NOT NULL AND julianday(?) - julianday(substr(last_public_update_at, 1, 10)) >= ? THEN 'stalled'
                 ELSE 'watch'
               END AS attention_state
        FROM requests
        WHERE (due_date IS NOT NULL AND due_date < ?)
           OR (last_public_update_at IS NOT NULL AND julianday(?) - julianday(substr(last_public_update_at, 1, 10)) >= ?)
        ORDER BY attention_state DESC, due_date ASC, last_public_update_at ASC
        """,
        (as_of_date, as_of_date, stale_days, as_of_date, as_of_date, stale_days),
    ).fetchall()
