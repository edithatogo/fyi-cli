from __future__ import annotations

from pydantic import BaseModel, Field


class RequestDraft(BaseModel):
    authority_slug: str = Field(min_length=1)
    title: str = Field(min_length=1)
    body: str = Field(min_length=1)
    default_letter: str | None = None
    tags: list[str] = Field(default_factory=list)


class FeedEntry(BaseModel):
    title: str
    link: str
    published: str | None = None
    summary: str | None = None


class Authority(BaseModel):
    name: str
    slug: str
    url: str | None = None
    notes: str | None = None


class RequestRecord(BaseModel):
    title: str
    authority_slug: str
    request_url: str | None = None
    status: str = "draft"
    tags: list[str] = Field(default_factory=list)
    summary: str | None = None


class RequestPage(BaseModel):
    url: str
    title: str | None = None
    status: str | None = None
    described_state: str | None = None
    authority_name: str | None = None
    requested_date: str | None = None
    due_date: str | None = None
    last_public_update_at: str | None = None
    raw: dict = Field(default_factory=dict)


class SnapshotDiff(BaseModel):
    source_url: str
    previous_count: int
    current_count: int
    added_links: list[str] = Field(default_factory=list)
    removed_links: list[str] = Field(default_factory=list)
