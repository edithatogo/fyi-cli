# System overview

## Goal

Provide a local-first operating layer around FYI.org.nz so a user can manage drafting, monitoring, analysis, and handover without depending on undocumented write APIs.

## Components

1. Local SQLite database
   - authorities
   - requests
   - request page state
   - feed events
   - feed snapshots
2. Python CLI
   - import, register, ingest, fetch, report, handover
3. Conductor project context
   - persistent product and workflow documents
   - phase-based tracks
4. Prompt and skill packs
   - drafting, review, handover, monitoring

## Operating model

- Draft locally.
- Generate a prefilled FYI request URL.
- Submit through FYI with a human step.
- Poll feed views and request JSON pages.
- Persist normalized fields in SQLite.
- Produce attention reports and handovers for continuity.
