# Tooling and skill packs

## Included skill packs

- `context-manager`: maintain project context and track state
- `request-drafter`: generate requests with scope and phrasing discipline
- `request-register`: keep a local record before public submission
- `fyi-monitor`: poll feeds, fetch request JSON, and update the DB
- `handover-writer`: generate continuity notes for the next operator
- `attention-triage`: review overdue and stalled items
- `phase-3-operator`: run the full phase 3 monitoring workflow

## Suggested external tools

- Gemini CLI + Conductor
- Ralph
- `uv`
- `pre-commit`
- `ruff`
- `mypy`
- `pytest`
- SQLite browser for manual inspection if desired
