# Daily operations runbook

1. Activate the environment.
2. Sync or import authorities if needed.
3. Register new draft requests locally.
4. Submit through FYI using the generated prefilled URL.
5. Ingest relevant feeds.
6. Fetch request JSON for tracked items.
7. Generate the attention report.
8. Generate the markdown handover.
9. Commit updated context and outputs.

## Suggested sequence

```bash
fyi-system ingest-feed "https://fyi.org.nz/search/health/feed"
fyi-system fetch-request-page 1
fyi-system fetch-request-page 2
fyi-system attention-report --output outputs/attention-report.json
fyi-system handover --output outputs/handover.md
```
