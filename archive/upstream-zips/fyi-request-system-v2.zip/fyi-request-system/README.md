# FYI Request System

A Conductor-oriented repository scaffold for an **assisted** Official Information Act request workflow around FYI.org.nz.

This repo is designed for:
- drafting requests from templates
- selecting and validating authorities
- generating prefilled FYI request URLs
- polling public feeds / JSON pages for updates
- storing request metadata locally
- producing follow-up drafts, summaries, and handovers

This repo is **not** a headless submission bot for FYI, and it does **not** include IP-masking, Tor routing, or evasion tooling.

## Why this shape?
FYI documents a partial API surface rather than a full submission-management API: prefilled request links, Atom feeds, JSON versions of many pages, and authority exports. That makes an assisted workflow a good fit rather than full API-driven request management. See FYI's API help page and Conductor's setup/newTrack/implement workflow docs.

## Repo structure

```text
conductor/                  Project context and track plans
prompts/                    Prompt templates for drafting, review, and monitoring
skills/                     Reusable Skill-style instruction packs (SKILL.md)
docs/architecture/          System design, risk notes, data model
docs/handover/              Operator handover and runbook materials
src/fyi_system/             Python package
tests/                      Unit tests
scripts/                    Helper scripts
```

## Safe operating model

1. Draft request locally.
2. Validate authority and metadata.
3. Generate a prefilled FYI request URL.
4. Human reviews and submits in browser.
5. Poll feed / JSON pages for updates.
6. Draft follow-up, escalation, and summary text.

## Suggested local setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
pytest
python -m fyi_system.cli --help
```

## Conductor usage

Install Conductor in Gemini CLI:

```bash
gemini extensions install https://github.com/gemini-cli-extensions/conductor --auto-update
```

Conductor's documented lifecycle is:
- `/conductor:setup` to scaffold project context
- `/conductor:newTrack` to create a track with `spec.md` and `plan.md`
- `/conductor:implement` to work through the plan and update status in `tracks.md` and the track plan.


## Phase 2 additions

This updated scaffold now includes:
- SQLite persistence under `data/fyi.db`
- authority CSV import
- local request registration before browser submission
- richer handover/runbook materials
- a second Conductor track for incremental implementation

### Example commands

```bash
fyi-system init-db
fyi-system import-authorities data/all-authorities.csv
fyi-system register-request auckland_council "Service metrics request" "Please provide..." --tags "topic:metrics"
fyi-system list-authorities
```

## Important note on networking

This scaffold intentionally avoids anonymous routing, proxy chaining, and Tor usage. For privacy and compliance, use ordinary, lawful networking and review FYI's terms, robots, and public-service norms before automation.
