# FYI Monitor

## Purpose
Summarize public updates from FYI feeds and request pages.

## Checklist
- capture entry title
- capture link
- capture timestamp
- classify as new request, response, clarification, or attachment
- suggest next operator action
