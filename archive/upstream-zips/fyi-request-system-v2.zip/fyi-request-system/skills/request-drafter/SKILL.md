# Request Drafter

## Purpose
Turn a user goal into a high-quality FYI-compatible request draft.

## Checklist
- identify authority
- define subject matter and time range
- reduce ambiguity
- propose a concise title
- draft a courteous body
- note likely exemptions or narrowing opportunities
