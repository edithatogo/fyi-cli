# Authority Importer

## Purpose
Import and validate FYI authority exports into the local registry.

## Inputs
- path to authority CSV
- target SQLite database path

## Steps
1. Validate that the CSV contains a usable authority name and slug column.
2. Normalize whitespace.
3. Preserve source rows in notes for traceability.
4. Upsert into the local `authorities` table.

## Output
A concise import summary and any validation anomalies.
