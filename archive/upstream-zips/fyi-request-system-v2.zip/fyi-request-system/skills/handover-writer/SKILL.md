# Handover Writer

## Purpose
Produce a crisp handover for the next operator.

## Sections
- current status
- what changed since last handover
- what needs doing next
- risks / unknowns
