# Context Manager

## Purpose
Maintain durable project context for FYI drafting and monitoring work.

## Inputs
- request metadata
- authority details
- current task
- prior handover notes

## Outputs
- updated context summary
- next actions
- unresolved questions

## Rules
- keep summaries brief and factual
- do not infer facts not in evidence
- record provenance for external data
