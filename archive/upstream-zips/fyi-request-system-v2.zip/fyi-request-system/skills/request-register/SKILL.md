# Request Register

## Purpose
Create a durable local record for a draft request before human submission.

## Inputs
- authority slug
- request title
- request body
- tags
- optional summary

## Steps
1. Build the FYI prefilled request URL.
2. Store the draft in SQLite.
3. Return the prefilled URL and local request id.
4. Remind the operator that submission remains manual.
