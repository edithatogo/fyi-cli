from fyi_system.fyi_urls import build_prefilled_request_url
from fyi_system.models import RequestDraft


def test_build_prefilled_request_url() -> None:
    draft = RequestDraft(
        authority_slug="ministry-of-health",
        title="OIA request",
        body="Please provide documents.",
        default_letter="Kia ora",
        tags=["health", "briefing"],
    )
    url = build_prefilled_request_url(draft)
    assert url.startswith("https://fyi.org.nz/new/ministry-of-health?")
    assert "title=OIA+request" in url
    assert "body=Please+provide+documents." in url
    assert "default_letter=Kia+ora" in url
    assert "tags=health+briefing" in url
