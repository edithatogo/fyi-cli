from pathlib import Path

from fyi_system.storage import authorities_from_csv


def test_authorities_from_csv(tmp_path: Path) -> None:
    csv_path = tmp_path / "authorities.csv"
    csv_path.write_text("name,url_name,url\nAuckland Council,auckland_council,https://example.test\n", encoding="utf-8")
    authorities = authorities_from_csv(csv_path)
    assert len(authorities) == 1
    assert authorities[0].slug == "auckland_council"
