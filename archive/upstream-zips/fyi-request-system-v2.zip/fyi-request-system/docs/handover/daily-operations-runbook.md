# Daily operations runbook

## Start of day
1. Activate the environment.
2. Run `fyi-system init-db` if this is a fresh clone.
3. Import authorities from the latest CSV when needed.
4. Poll relevant public feeds and save snapshots under `data/feeds/`.
5. Review open requests and prepare follow-ups.

## Drafting path
1. Draft locally from `prompts/request_draft.md`.
2. Register the draft with `fyi-system register-request`.
3. Open the returned prefilled FYI URL in a browser.
4. Human reviews and submits.

## Monitoring path
1. Poll a feed.
2. Compare latest entries with prior snapshots.
3. Update the local handover and request summary.

## Governance notes
- Treat FYI as the public record layer.
- Keep the human in the loop for submission and any sensitive follow-up.
- Do not use network-evasion tooling, proxy chaining, or Tor for this workflow.
