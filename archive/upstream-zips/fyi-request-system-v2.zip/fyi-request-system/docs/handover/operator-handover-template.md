# Operator Handover

## Current objective

## Active requests

## Outstanding follow-up actions

## Risks / blockers

## Source links

## Notes for next operator
