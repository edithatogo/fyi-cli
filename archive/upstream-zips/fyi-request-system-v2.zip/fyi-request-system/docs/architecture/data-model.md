# Data model

## authorities
Stores authority names and slugs imported from FYI's authority export.

## requests
Stores local request intent, prefilled URL, tags, summary, and workflow status.

## events
Stores snapshots of feed-derived public events for later comparison and handover.

This model is intentionally local-first and conservative because FYI exposes a partial API surface rather than a full submission-management API.
