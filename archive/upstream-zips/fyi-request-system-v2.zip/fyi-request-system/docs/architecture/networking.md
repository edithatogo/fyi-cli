# Networking and privacy posture

This repository is designed for ordinary, transparent access to FYI public pages and feeds.

Included:
- standard HTTPS client usage
- local file snapshots
- local SQLite state

Not included:
- Tor
- proxy chaining
- IP masking or rotation
- anti-detection tooling

If organisational networking is required, use ordinary approved outbound networking and document it separately.
