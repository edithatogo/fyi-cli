# System Overview

## Components
- draft engine
- authority registry
- FYI URL builder
- feed poller
- request store
- handover generator

## Data flow
1. User enters request details.
2. Local validator normalizes metadata.
3. URL builder creates a prefilled FYI link.
4. User reviews and submits in browser.
5. Feed poller watches public updates.
6. Handover writer summarizes state.

## Security and privacy
- No anonymous routing features are provided.
- Keep secrets out of the repo.
- Use ordinary outbound networking.
