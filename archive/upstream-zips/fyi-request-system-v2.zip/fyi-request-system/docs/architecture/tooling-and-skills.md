# Recommended tools and SKILL.md files

## Gemini CLI extensions
- Conductor: project context, tracks, plans, implementation lifecycle.
- Ralph: optional iterative refinement loops for prompts, specs, and documentation.

## Useful repo-local skill packs
- `skills/context-manager/SKILL.md`
- `skills/request-drafter/SKILL.md`
- `skills/fyi-monitor/SKILL.md`
- `skills/handover-writer/SKILL.md`

## Optional non-skill tooling
- `direnv` for local env handling
- `just` or `make` for common commands
- `pre-commit` for linting
- SQLite for local persistence if you want durable state
