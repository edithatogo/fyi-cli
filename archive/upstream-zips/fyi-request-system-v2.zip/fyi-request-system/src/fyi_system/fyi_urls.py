from __future__ import annotations

from urllib.parse import urlencode

from .models import RequestDraft

BASE_URL = "https://fyi.org.nz/new"


def build_prefilled_request_url(draft: RequestDraft) -> str:
    params: dict[str, str] = {
        "title": draft.title,
        "body": draft.body,
    }
    if draft.default_letter:
        params["default_letter"] = draft.default_letter
    if draft.tags:
        params["tags"] = " ".join(draft.tags)
    query = urlencode(params)
    return f"{BASE_URL}/{draft.authority_slug}?{query}"
