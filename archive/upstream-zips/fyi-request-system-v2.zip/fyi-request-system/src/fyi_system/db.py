from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Iterable

from .models import Authority, RequestRecord

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS authorities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    url TEXT,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    authority_slug TEXT NOT NULL,
    request_url TEXT,
    status TEXT NOT NULL DEFAULT 'draft',
    tags TEXT NOT NULL DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    summary TEXT,
    FOREIGN KEY (authority_slug) REFERENCES authorities(slug)
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id INTEGER,
    source_url TEXT NOT NULL,
    event_id TEXT,
    title TEXT NOT NULL,
    link TEXT,
    published_at TEXT,
    payload_json TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES requests(id)
);

CREATE INDEX IF NOT EXISTS idx_requests_authority_slug ON requests(authority_slug);
CREATE INDEX IF NOT EXISTS idx_events_request_id ON events(request_id);
"""


def connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def upsert_authorities(conn: sqlite3.Connection, authorities: Iterable[Authority]) -> int:
    count = 0
    for authority in authorities:
        conn.execute(
            """
            INSERT INTO authorities(name, slug, url, notes)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(slug) DO UPDATE SET
              name=excluded.name,
              url=excluded.url,
              notes=excluded.notes
            """,
            (authority.name, authority.slug, authority.url, authority.notes),
        )
        count += 1
    conn.commit()
    return count


def insert_request(conn: sqlite3.Connection, record: RequestRecord) -> int:
    cursor = conn.execute(
        """
        INSERT INTO requests(title, authority_slug, request_url, status, tags, summary)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            record.title,
            record.authority_slug,
            record.request_url,
            record.status,
            " ".join(record.tags),
            record.summary,
        ),
    )
    conn.commit()
    return int(cursor.lastrowid)
