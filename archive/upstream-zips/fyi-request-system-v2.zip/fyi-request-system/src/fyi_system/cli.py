from __future__ import annotations

import json
from pathlib import Path

import typer
from rich import print
from rich.table import Table

from .db import connect, insert_request, upsert_authorities
from .feeds import parse_feed
from .fyi_urls import build_prefilled_request_url
from .models import RequestDraft, RequestRecord
from .storage import authorities_from_csv, save_feed_entries

app = typer.Typer(help="FYI request system CLI")
DEFAULT_DB = Path("data/fyi.db")


def _ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


@app.command("init-db")
def init_db(db: Path = DEFAULT_DB) -> None:
    _ensure_parent(db)
    connect(db).close()
    print(f"Initialised database at {db}")


@app.command("draft-url")
def draft_url(
    authority_slug: str,
    title: str,
    body: str,
    default_letter: str = "",
    tags: str = "",
) -> None:
    draft = RequestDraft(
        authority_slug=authority_slug,
        title=title,
        body=body,
        default_letter=default_letter or None,
        tags=[tag for tag in tags.split() if tag],
    )
    print(build_prefilled_request_url(draft))


@app.command("register-request")
def register_request(
    authority_slug: str,
    title: str,
    body: str,
    db: Path = DEFAULT_DB,
    tags: str = "",
    status: str = "draft",
    summary: str = "",
) -> None:
    _ensure_parent(db)
    draft = RequestDraft(
        authority_slug=authority_slug,
        title=title,
        body=body,
        tags=[tag for tag in tags.split() if tag],
    )
    url = build_prefilled_request_url(draft)
    conn = connect(db)
    request_id = insert_request(
        conn,
        RequestRecord(
            title=title,
            authority_slug=authority_slug,
            request_url=url,
            status=status,
            tags=[tag for tag in tags.split() if tag],
            summary=summary or None,
        ),
    )
    print(f"Registered request #{request_id}: {url}")


@app.command("import-authorities")
def import_authorities(csv_path: Path, db: Path = DEFAULT_DB) -> None:
    _ensure_parent(db)
    authorities = authorities_from_csv(csv_path)
    conn = connect(db)
    count = upsert_authorities(conn, authorities)
    print(f"Imported {count} authorities into {db}")


@app.command("list-authorities")
def list_authorities(limit: int = 20, db: Path = DEFAULT_DB) -> None:
    conn = connect(db)
    rows = conn.execute(
        "SELECT name, slug, url FROM authorities ORDER BY name LIMIT ?", (limit,)
    ).fetchall()
    table = Table(title="Authorities")
    table.add_column("Name")
    table.add_column("Slug")
    table.add_column("URL")
    for row in rows:
        table.add_row(row["name"], row["slug"], row["url"] or "")
    print(table)


@app.command("poll-feed")
def poll_feed(url: str, output: Path | None = None) -> None:
    entries = parse_feed(url)
    if output:
        _ensure_parent(output)
        save_feed_entries(output, entries)
        print(f"Wrote {len(entries)} entries to {output}")
    else:
        print(json.dumps([entry.model_dump(mode="json") for entry in entries], indent=2))


if __name__ == "__main__":
    app()
