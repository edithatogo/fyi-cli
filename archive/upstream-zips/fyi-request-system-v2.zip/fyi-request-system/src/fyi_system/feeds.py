from __future__ import annotations

import feedparser

from .models import FeedEntry



def parse_feed(url: str) -> list[FeedEntry]:
    parsed = feedparser.parse(url)
    entries: list[FeedEntry] = []
    for entry in parsed.entries:
        entries.append(
            FeedEntry(
                title=getattr(entry, "title", ""),
                link=getattr(entry, "link", ""),
                published=getattr(entry, "published", None),
                summary=getattr(entry, "summary", None),
            )
        )
    return entries
