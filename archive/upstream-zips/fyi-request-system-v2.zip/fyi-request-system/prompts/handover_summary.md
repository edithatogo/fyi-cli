# Handover summary prompt

Prepare an operator handover for an assisted FYI request workflow.

Include:
- objective of each open request
- authority and slug
- current public status
- next action and due date
- risks or sensitivities
- links to local request registry entries and any feed snapshots
