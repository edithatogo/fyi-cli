Review the latest FYI feed entries and produce:
- new activity summary
- likely due dates / stale items
- recommended follow-up actions
- one-paragraph handover note
