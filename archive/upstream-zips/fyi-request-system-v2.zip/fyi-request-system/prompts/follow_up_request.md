# Follow-up request prompt

You are drafting a concise, courteous OIA follow-up for FYI.org.nz.

Inputs:
- original request title
- authority
- original request text
- days since submission
- latest published update or response summary
- desired tone: professional, firm, not antagonistic

Output:
1. Brief assessment of status
2. Draft follow-up text suitable for FYI publication
3. Optional escalation note for internal tracking
