# Spec - Assisted FYI drafting and monitoring workflow

## Problem
The operator needs a repeatable system to draft structured FYI requests, generate prefilled request URLs, monitor public updates, and produce handovers.

## Scope
- local request record model
- authority model
- prefilled FYI URL builder
- feed polling module
- CLI entrypoints
- prompt and handover packs

## Out of scope
- stealth networking
- Tor/proxy chaining
- account automation
- CAPTCHA or moderation bypass
