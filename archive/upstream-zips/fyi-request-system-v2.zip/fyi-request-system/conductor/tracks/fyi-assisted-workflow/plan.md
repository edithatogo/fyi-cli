# Plan - Assisted FYI drafting and monitoring workflow

## Phase 1 - Foundations
- [x] Create Conductor project context
- [x] Add Python package scaffold
- [x] Add prompt, handover, and skill packs
- [ ] Add local persistence layer

## Phase 2 - Core features
- [x] Implement FYI prefilled URL builder
- [x] Implement Atom feed reader
- [ ] Implement JSON page fetcher
- [ ] Implement authority import from CSV

## Phase 3 - Operator workflow
- [x] Add CLI commands for draft-url and poll-feed
- [ ] Add generate-handover command
- [ ] Add follow-up drafting flow

## Phase 4 - Quality
- [x] Add unit tests for URL builder
- [ ] Add tests for feed parsing
- [ ] Add documentation review
