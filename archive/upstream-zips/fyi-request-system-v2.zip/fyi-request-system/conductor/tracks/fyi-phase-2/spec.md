# Track: FYI phase 2 local registry and monitoring

## Goal
Extend the initial scaffold into a working local-first request support system.

## Requirements
- add SQLite persistence
- import authorities from CSV
- register drafts locally
- capture feed snapshots
- improve operator handover materials
- keep human-in-the-loop submission

## Non-goals
- headless FYI submission
- anonymous routing or IP masking
- automated circumvention of public-site controls
