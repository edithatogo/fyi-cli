# Plan

- [x] Add a local SQLite schema for authorities, requests, and events.
- [x] Add CLI commands for database init, authority import, and request registration.
- [x] Add prompt templates for follow-up and handover.
- [x] Add runbook and architecture notes.
- [ ] Add request-page JSON fetch and normalization.
- [ ] Add diffing across feed snapshots.
- [ ] Add reporting command for overdue and stalled requests.
