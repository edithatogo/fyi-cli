# Product Guidelines

- Prefer lawful, transparent, low-friction automation.
- Keep a human in the loop at submission points.
- Respect source sites, robots rules, and public-service expectations.
- Write requests that are specific, polite, and easy for an agency to process.
- Preserve provenance for every generated artifact.
- Avoid over-collection of personal data.
