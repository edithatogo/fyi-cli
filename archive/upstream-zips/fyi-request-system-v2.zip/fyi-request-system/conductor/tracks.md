# Tracks Registry

| Track ID | Title | Status | Path |
|---|---|---:|---|
| fyi-assisted-workflow | Assisted FYI drafting and monitoring workflow | planned | conductor/tracks/fyi-assisted-workflow/ |

- `fyi-phase-2` — in progress — local registry, authority import, feed snapshots, handover hardening
