# Product Context

## Name
FYI Request System

## Purpose
Provide a safe, assisted workflow for drafting, tracking, and reviewing FYI.org.nz OIA requests using public FYI interfaces.

## Primary users
- researcher
- journalist
- policy analyst
- legal/policy support operator

## Core jobs to be done
- find the right authority
- draft a high-quality request
- generate a prefilled FYI request URL
- monitor public request updates
- produce follow-up and handover notes

## Non-goals
- bypassing site controls
- anonymous routing or identity masking
- automated account creation
- headless submission designed to evade moderation or rate controls
