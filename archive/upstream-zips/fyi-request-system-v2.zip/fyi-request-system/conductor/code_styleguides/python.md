# Python Style Guide

- Use type hints.
- Keep modules small and explicit.
- Prefer pure functions for transformation steps.
- Use pydantic models for request/response shapes.
- Do not hide network behavior.
