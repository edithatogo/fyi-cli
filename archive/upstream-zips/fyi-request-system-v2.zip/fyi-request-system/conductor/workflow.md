# Project Workflow

1. Plan is authoritative.
2. Keep tasks small and reviewable.
3. Write tests for URL generation, parsing, and persistence.
4. Require manual verification before any live polling changes are merged.
5. Keep network behavior conservative.
6. Prefer idempotent scripts.
7. Record handover notes after each completed phase.
