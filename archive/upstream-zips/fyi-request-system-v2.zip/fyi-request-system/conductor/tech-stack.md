# Tech Stack

- Python 3.10+
- httpx for HTTP
- feedparser for Atom feeds
- pydantic for schemas
- typer for CLI
- pytest for tests
- local Markdown files for context and handover

## Notes
This project targets an assisted browser-based submission flow because FYI documents partial API-like interfaces rather than a full submission API.
