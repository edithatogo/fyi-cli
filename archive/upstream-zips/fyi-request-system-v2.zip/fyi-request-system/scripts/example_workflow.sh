#!/usr/bin/env bash
set -euo pipefail

python -m fyi_system.cli init-db
python -m fyi_system.cli import-authorities data/all-authorities.csv
python -m fyi_system.cli register-request \
  auckland_council \
  "Official Information Act request about service metrics" \
  "Please provide the monthly service metrics for 2025." \
  --tags "project:demo batch:2026-03"
