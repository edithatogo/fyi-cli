# Bootstrap Notes

After cloning:
1. install Python deps
2. install Conductor in Gemini CLI
3. optionally install Ralph for refinement loops
4. run `/conductor:setup` if you want Conductor to regenerate context interactively
5. create the first real track with `/conductor:newTrack`
