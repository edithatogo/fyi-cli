from __future__ import annotations

import json
from pathlib import Path

import typer
from rich import print

from .feeds import parse_feed
from .fyi_urls import build_prefilled_request_url
from .models import RequestDraft

app = typer.Typer(help="FYI request system CLI")


@app.command("draft-url")
def draft_url(
    authority_slug: str,
    title: str,
    body: str,
    default_letter: str = "",
    tags: str = "",
) -> None:
    draft = RequestDraft(
        authority_slug=authority_slug,
        title=title,
        body=body,
        default_letter=default_letter or None,
        tags=[tag for tag in tags.split() if tag],
    )
    print(build_prefilled_request_url(draft))


@app.command("poll-feed")
def poll_feed(url: str, output: Path | None = None) -> None:
    entries = parse_feed(url)
    payload = [entry.model_dump() for entry in entries]
    if output:
        output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(f"Wrote {len(payload)} entries to {output}")
    else:
        print_json = json.dumps(payload, indent=2)
        print(print_json)


if __name__ == "__main__":
    app()
