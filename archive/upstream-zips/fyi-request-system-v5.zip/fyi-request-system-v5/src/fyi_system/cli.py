from __future__ import annotations
import argparse
import json
from .db import init_db, query_all, connect
from .fyi import build_prefilled_url
from .importers import import_authorities_csv
from .monitor import ingest_feed, reconcile_events
from .fetch import fetch_request_page, summarize_request_json
from .reporting import write_attention_report, write_handover
from .dashboard import write_dashboard
from .scheduler import run_scheduler, run_cycle
from .webapp import serve

def cmd_init_db(args):
    init_db(args.db)
    print(f"Initialized {args.db}")

def cmd_import_authorities(args):
    n = import_authorities_csv(args.csv_path, db_path=args.db)
    print(f"Imported {n} authorities")

def cmd_list_authorities(args):
    rows = query_all(args.db, 'SELECT slug, name, url FROM authorities ORDER BY name')
    for row in rows:
        print(f"{row['slug']}\t{row['name']}\t{row['url'] or ''}")

def cmd_register_request(args):
    conn = connect(args.db)
    try:
        conn.execute('INSERT INTO tracked_requests(authority_slug, title, body, tags, status, fyi_request_id) VALUES (?, ?, ?, ?, ?, ?)', (args.authority_slug, args.title, args.body, args.tags or '', args.status, args.fyi_request_id))
        conn.commit()
        print('Registered request')
    finally:
        conn.close()

def cmd_list_requests(args):
    rows = query_all(args.db, 'SELECT id, authority_slug, title, status, fyi_request_id FROM tracked_requests ORDER BY id')
    for row in rows:
        print(f"{row['id']}\t{row['authority_slug']}\t{row['title']}\t{row['status']}\t{row['fyi_request_id'] or ''}")

def cmd_build_prefilled_url(args):
    tags = [t for t in (args.tags or '').split(',') if t]
    print(build_prefilled_url(args.authority_slug, args.title, args.body, tags=tags, base_url=args.base_url))

def cmd_ingest_feed(args):
    print(ingest_feed(args.feed_url, db_path=args.db))

def cmd_reconcile(args):
    print(reconcile_events(db_path=args.db))

def cmd_fetch_request_page(args):
    data = fetch_request_page(args.request_id, base_url=args.base_url, db_path=args.db)
    print(json.dumps(summarize_request_json(data), indent=2, ensure_ascii=False))

def cmd_attention_report(args):
    print(write_attention_report(args.output, db_path=args.db))

def cmd_handover(args):
    print(write_handover(args.output, db_path=args.db))

def cmd_dashboard(args):
    print(write_dashboard(args.output, db_path=args.db, json_output=args.json_output))

def cmd_run_cycle(args):
    print(json.dumps(run_cycle(args.feed_url, db_path=args.db, outputs_dir=args.outputs_dir), indent=2))

def cmd_scheduler(args):
    run_scheduler(args.feed_url, interval_seconds=args.interval_seconds, db_path=args.db, outputs_dir=args.outputs_dir, once=args.once)

def cmd_serve(args):
    serve(host=args.host, port=args.port, db_path=args.db)

def build_parser():
    p = argparse.ArgumentParser(prog='fyi-system')
    sub = p.add_subparsers(dest='cmd', required=True)
    sp = sub.add_parser('init-db'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_init_db)
    sp = sub.add_parser('import-authorities'); sp.add_argument('csv_path'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_import_authorities)
    sp = sub.add_parser('list-authorities'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_list_authorities)
    sp = sub.add_parser('register-request'); sp.add_argument('authority_slug'); sp.add_argument('title'); sp.add_argument('body'); sp.add_argument('--tags'); sp.add_argument('--status', default='draft'); sp.add_argument('--fyi-request-id', type=int); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_register_request)
    sp = sub.add_parser('list-requests'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_list_requests)
    sp = sub.add_parser('build-prefilled-url'); sp.add_argument('authority_slug'); sp.add_argument('title'); sp.add_argument('body'); sp.add_argument('--tags'); sp.add_argument('--base-url', default='https://fyi.org.nz'); sp.set_defaults(func=cmd_build_prefilled_url)
    sp = sub.add_parser('ingest-feed'); sp.add_argument('feed_url'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_ingest_feed)
    sp = sub.add_parser('reconcile-events'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_reconcile)
    sp = sub.add_parser('fetch-request-page'); sp.add_argument('request_id', type=int); sp.add_argument('--base-url', default='https://fyi.org.nz'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_fetch_request_page)
    sp = sub.add_parser('attention-report'); sp.add_argument('--output', default='outputs/attention-report.json'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_attention_report)
    sp = sub.add_parser('handover'); sp.add_argument('--output', default='outputs/handover.md'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_handover)
    sp = sub.add_parser('dashboard'); sp.add_argument('--output', default='outputs/dashboard.html'); sp.add_argument('--json-output'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_dashboard)
    sp = sub.add_parser('run-cycle'); sp.add_argument('feed_url'); sp.add_argument('--outputs-dir', default='outputs'); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_run_cycle)
    sp = sub.add_parser('scheduler'); sp.add_argument('feed_url'); sp.add_argument('--interval-seconds', type=int, default=3600); sp.add_argument('--outputs-dir', default='outputs'); sp.add_argument('--db', default='fyi_system.db'); sp.add_argument('--once', action='store_true'); sp.set_defaults(func=cmd_scheduler)
    sp = sub.add_parser('serve'); sp.add_argument('--host', default='127.0.0.1'); sp.add_argument('--port', type=int, default=8000); sp.add_argument('--db', default='fyi_system.db'); sp.set_defaults(func=cmd_serve)
    return p

def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)

if __name__ == '__main__':
    main()
