from __future__ import annotations
import json
from pathlib import Path
from jinja2 import Template
from .reporting import attention_report
from .db import query_all

HTML_TEMPLATE = Template("""
<!doctype html>
<html>
<head>
  <meta charset='utf-8'>
  <title>FYI Request System Dashboard</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 2rem; }
    .cards { display: flex; gap: 1rem; flex-wrap: wrap; }
    .card { border: 1px solid #ddd; border-radius: 10px; padding: 1rem; min-width: 180px; }
    table { border-collapse: collapse; width: 100%; margin-top: 1rem; }
    th, td { border-bottom: 1px solid #eee; padding: 0.5rem; text-align: left; }
    .pill { display: inline-block; padding: 0.2rem 0.5rem; border-radius: 999px; background: #f1f5f9; }
  </style>
</head>
<body>
  <h1>FYI Request System Dashboard</h1>
  <div class='cards'>
    <div class='card'><div>Total tracked</div><strong>{{ summary.total }}</strong></div>
    <div class='card'><div>Needs attention</div><strong>{{ summary.attention }}</strong></div>
    <div class='card'><div>Authorities</div><strong>{{ summary.authorities }}</strong></div>
  </div>
  <h2>Tracked requests</h2>
  <table>
    <thead><tr><th>ID</th><th>Title</th><th>Status</th><th>FYI</th><th>Last event</th></tr></thead>
    <tbody>
      {% for item in items %}
      <tr>
        <td>{{ item.id }}</td>
        <td>{{ item.title }}</td>
        <td><span class='pill'>{{ item.status }}</span></td>
        <td>{{ item.fyi_request_id or '' }}</td>
        <td>{{ item.last_event_title or '' }}</td>
      </tr>
      {% endfor %}
    </tbody>
  </table>
</body>
</html>
""")

def dashboard_payload(db_path: str | Path = 'fyi_system.db') -> dict:
    report = attention_report(db_path)
    authorities = query_all(db_path, 'SELECT COUNT(*) AS c FROM authorities')[0]['c']
    return {
        'summary': {
            'total': report['count'],
            'attention': sum(1 for i in report['items'] if i['needs_attention']),
            'authorities': authorities,
        },
        'items': report['items'],
    }

def write_dashboard(html_output: str | Path, db_path: str | Path = 'fyi_system.db', json_output: str | Path | None = None) -> Path:
    payload = dashboard_payload(db_path)
    html_path = Path(html_output)
    html_path.parent.mkdir(parents=True, exist_ok=True)
    html_path.write_text(HTML_TEMPLATE.render(**payload), encoding='utf-8')
    if json_output:
        json_path = Path(json_output)
        json_path.parent.mkdir(parents=True, exist_ok=True)
        json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return html_path
