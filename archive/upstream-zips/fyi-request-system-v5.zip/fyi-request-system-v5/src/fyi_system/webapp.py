from __future__ import annotations
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from .dashboard import dashboard_payload, write_dashboard
from .db import init_db
from .fyi import build_prefilled_url

def make_handler(db_path: str):
    class Handler(BaseHTTPRequestHandler):
        def _json(self, payload: dict, status: int = 200):
            data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        def _html(self, html: str, status: int = 200):
            data = html.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path == '/api/dashboard':
                return self._json(dashboard_payload(db_path))
            if parsed.path == '/':
                temp = Path('.dashboard_temp.html')
                write_dashboard(temp, db_path=db_path)
                html = temp.read_text(encoding='utf-8')
                temp.unlink(missing_ok=True)
                return self._html(html)
            return self._json({'error': 'not found'}, status=404)
        def do_POST(self):
            parsed = urlparse(self.path)
            if parsed.path != '/api/draft-url':
                return self._json({'error': 'not found'}, status=404)
            length = int(self.headers.get('Content-Length', '0'))
            body = self.rfile.read(length).decode('utf-8')
            payload = json.loads(body) if body else {}
            url = build_prefilled_url(payload.get('authority_slug', ''), payload.get('title', ''), payload.get('body', ''), tags=payload.get('tags', []))
            return self._json({'url': url})
        def log_message(self, fmt, *args):
            return
    return Handler

def serve(host: str = '127.0.0.1', port: int = 8000, db_path: str = 'fyi_system.db'):
    init_db(db_path)
    server = ThreadingHTTPServer((host, port), make_handler(db_path))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
