from __future__ import annotations
import csv
from pathlib import Path
from .db import connect

def import_authorities_csv(csv_path: str | Path, db_path: str | Path = 'fyi_system.db') -> int:
    conn = connect(db_path)
    count = 0
    try:
        with open(csv_path, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                slug = (row.get('url_name') or row.get('slug') or '').strip()
                name = (row.get('name') or '').strip()
                url = (row.get('url') or '').strip() or None
                if not slug or not name:
                    continue
                conn.execute(
                    'INSERT INTO authorities(slug, name, url) VALUES (?, ?, ?) ON CONFLICT(slug) DO UPDATE SET name=excluded.name, url=excluded.url',
                    (slug, name, url),
                )
                count += 1
        conn.commit()
        return count
    finally:
        conn.close()
