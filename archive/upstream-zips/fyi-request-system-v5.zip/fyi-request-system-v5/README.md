# FYI Request System v5

A local-first assisted workflow for working with FYI.org.nz request drafts, tracking, feeds, snapshots,
and operator handovers.

This repository is designed around Conductor's context-driven workflow:
Context -> Spec & Plan -> Implement.

## What this repo does

- Builds prefilled FYI draft URLs
- Stores authorities and tracked requests in SQLite
- Ingests Atom feeds and request-page JSON
- Reconciles feed events back to tracked requests
- Generates attention reports and markdown handovers
- Serves a small local dashboard UI
- Includes Conductor context, tracks, prompts, and skills

## What this repo does not do

- It does not automate submission against FYI accounts
- It does not include proxy/Tor/IP-masking features
- It does not bypass rate limits, auth, or moderation

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e .[dev]

fyi-system init-db
fyi-system serve --host 127.0.0.1 --port 8000
```

Then open `http://127.0.0.1:8000/`.
