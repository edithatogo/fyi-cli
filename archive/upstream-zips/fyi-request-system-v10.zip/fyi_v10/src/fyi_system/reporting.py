from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from .db import get_tracked_request, query_all, request_timeline
from .fetch import latest_snapshot_summary


def attention_report(db_path: str | Path = 'fyi_system.db') -> dict:
    rows = query_all(db_path, 'SELECT * FROM tracked_requests ORDER BY updated_at DESC, id DESC')
    items = []
    for row in rows:
        needs_attention = row['status'] in {'draft', 'open', 'awaiting'} or row['last_event_title'] is None
        items.append(
            {
                'id': row['id'],
                'title': row['title'],
                'status': row['status'],
                'fyi_request_id': row['fyi_request_id'],
                'needs_attention': bool(needs_attention),
                'last_event_title': row['last_event_title'],
            }
        )
    return {'count': len(items), 'items': items}


def write_attention_report(output_path: str | Path, db_path: str | Path = 'fyi_system.db') -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(attention_report(db_path), indent=2, ensure_ascii=False), encoding='utf-8')
    return output


def build_handover_markdown(db_path: str | Path = 'fyi_system.db') -> str:
    report = attention_report(db_path)
    lines = ['# FYI Request System Handover', '', f"Tracked requests: {report['count']}", '', '## Attention queue', '']
    for item in report['items']:
        marker = 'ACTION' if item['needs_attention'] else 'OK'
        lines.append(
            f"- [{marker}] #{item['id']} {item['title']} (status: {item['status']}, FYI: {item['fyi_request_id']})"
        )
        tl = request_timeline(db_path, item['id'])[:2]
        for ev in tl:
            lines.append(f"  - {ev['ts']}: {ev['title']}")
    return "\n".join(lines) + "\n"


def write_handover(output_path: str | Path, db_path: str | Path = 'fyi_system.db') -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(build_handover_markdown(db_path), encoding='utf-8')
    return output


def _base_follow_up_context(db_path: str | Path, tracked_request_id: int) -> tuple[dict[str, Any], dict[str, Any] | None]:
    row = get_tracked_request(db_path, tracked_request_id)
    if not row:
        raise ValueError(f'Request {tracked_request_id} not found')
    snapshot = latest_snapshot_summary(db_path, row['fyi_request_id'])
    return dict(row), snapshot


def suggest_follow_up(db_path: str | Path, tracked_request_id: int) -> dict[str, Any]:
    row, snapshot = _base_follow_up_context(db_path, tracked_request_id)
    title = row['title']
    authority = row['authority_slug']
    status = (row['status'] or '').lower()
    snapshot_state = ((snapshot or {}).get('described_state') or '').lower()
    has_attachments = bool((snapshot or {}).get('attachments'))

    body_lines = [
        f'Kia ora {authority},',
        '',
        f'I’m following up on my request "{title}".',
    ]
    rationale = 'Generic follow-up based on tracked status.'
    stage = 'follow_up'

    if status == 'draft':
        rationale = 'Tracked request is still in draft and has not been submitted on FYI.'
        stage = 'submit_prompt'
        body_lines = [
            f'Draft ready for submission to {authority}.',
            '',
            f'Title: {title}',
            '',
            'Check the wording, confirm the authority, and submit through the prefilled FYI link.',
        ]
    elif snapshot_state in {'successful', 'partially_successful'} or has_attachments:
        rationale = 'Latest snapshot suggests a response or attachment is available.'
        stage = 'review_response'
        body_lines.extend(
            [
                'I can see that material may now be available on the request page.',
                'Could you please confirm whether this constitutes your full response, and whether any further material remains outstanding?',
                '',
                'If documents have been released, please identify any withheld material and the basis for any redactions or refusals.',
            ]
        )
    elif snapshot_state in {'waiting_response', 'internal_review', 'gone_postal'} or status in {'open', 'awaiting', 'submitted', 'awaiting_response'}:
        rationale = 'Latest tracked state suggests the request is still active without a complete response.'
        stage = 'nudge'
        body_lines.extend(
            [
                'I would be grateful for an update on the status of this request.',
                'If a decision has been made, please provide the response and any released material through the FYI request page.',
                '',
                'If you need refinement or clarification, please let me know.',
            ]
        )
    elif snapshot_state in {'rejected', 'not_held'}:
        rationale = 'Latest snapshot indicates a refusal or not-held outcome.'
        stage = 'challenge_or_refine'
        body_lines.extend(
            [
                'I note the current outcome recorded on the request page.',
                'Please clarify whether any part of the requested information is held elsewhere within the agency, or whether the request can be narrowed or transferred.',
            ]
        )
    else:
        body_lines.extend(
            [
                'I would be grateful for an update on the current status of this request.',
                'Please let me know if any clarification would assist.',
            ]
        )

    body_lines.extend(['', 'Ngā mihi'])
    subject = f'Follow-up: {title}'
    return {
        'tracked_request_id': tracked_request_id,
        'subject': subject,
        'body': "\n".join(body_lines).strip() + "\n",
        'stage': stage,
        'rationale': rationale,
        'snapshot_state': snapshot_state,
    }


def follow_up_variants(db_path: str | Path, tracked_request_id: int) -> dict[str, Any]:
    base = suggest_follow_up(db_path, tracked_request_id)
    row, snapshot = _base_follow_up_context(db_path, tracked_request_id)
    title = row['title']
    authority = row['authority_slug']
    snapshot_state = ((snapshot or {}).get('described_state') or '').lower()
    attachment_count = len((snapshot or {}).get('attachments', []))

    variants: list[dict[str, Any]] = []
    variants.append(
        {
            'strategy': 'polite_nudge',
            'subject': base['subject'],
            'body': base['body'],
            'why': 'Default, lowest-friction follow-up.',
        }
    )
    variants.append(
        {
            'strategy': 'firm_deadline_check',
            'subject': f'Status update requested: {title}',
            'body': "\n".join(
                [
                    f'Kia ora {authority},',
                    '',
                    f'I am writing to seek a clear status update on my request "{title}".',
                    'Please confirm whether a decision has now been made and, if so, provide the response and any released material via the FYI request page.',
                    '',
                    'If the request remains under consideration, please advise the current position and expected next step.',
                    '',
                    'Ngā mihi',
                ]
            )
            + "\n",
            'why': 'More direct wording when a request appears to have stalled.',
        }
    )
    if snapshot_state in {'successful', 'partially_successful'} or attachment_count:
        variants.append(
            {
                'strategy': 'review_released_material',
                'subject': f'Clarification on released material: {title}',
                'body': "\n".join(
                    [
                        f'Kia ora {authority},',
                        '',
                        f'Thank you for the material released in relation to "{title}".',
                        'Please confirm whether this is the full response, and identify any withheld material, redactions, or outstanding parts of the request.',
                        '',
                        'Ngā mihi',
                    ]
                )
                + "\n",
                'why': 'Best when documents or a substantive response appear to be available.',
            }
        )
    else:
        variants.append(
            {
                'strategy': 'clarify_scope',
                'subject': f'Clarification offered: {title}',
                'body': "\n".join(
                    [
                        f'Kia ora {authority},',
                        '',
                        f'If it would assist to process my request "{title}", I am happy to clarify or refine the scope.',
                        'Please let me know what narrowing or framing would be most useful while still capturing the information sought.',
                        '',
                        'Ngā mihi',
                    ]
                )
                + "\n",
                'why': 'Useful when delay may reflect uncertainty about scope.',
            }
        )
    return {
        'tracked_request_id': tracked_request_id,
        'snapshot_state': snapshot_state,
        'variants': variants,
    }


def write_follow_up_variants(output_path: str | Path, db_path: str | Path, tracked_request_id: int) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = follow_up_variants(db_path, tracked_request_id)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return output


def write_follow_up(output_path: str | Path, db_path: str | Path, tracked_request_id: int) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = suggest_follow_up(db_path, tracked_request_id)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return output


def attachment_manifest(db_path: str | Path, tracked_request_id: int) -> dict[str, Any]:
    row = get_tracked_request(db_path, tracked_request_id)
    if not row:
        raise ValueError(f'Request {tracked_request_id} not found')
    snapshot = latest_snapshot_summary(db_path, row['fyi_request_id']) or {}
    attachments = snapshot.get('attachments', [])
    return {
        'tracked_request_id': tracked_request_id,
        'fyi_request_id': row['fyi_request_id'],
        'title': row['title'],
        'attachments_count': len(attachments),
        'attachments': attachments,
    }


def write_attachment_manifest(output_path: str | Path, db_path: str | Path, tracked_request_id: int) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = attachment_manifest(db_path, tracked_request_id)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return output


def write_attachment_manifest_csv(output_path: str | Path, db_path: str | Path, tracked_request_id: int) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = attachment_manifest(db_path, tracked_request_id)
    with output.open('w', encoding='utf-8', newline='') as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=['tracked_request_id', 'fyi_request_id', 'title', 'name', 'url', 'content_type', 'size', 'path'],
        )
        writer.writeheader()
        for att in payload['attachments']:
            writer.writerow(
                {
                    'tracked_request_id': payload['tracked_request_id'],
                    'fyi_request_id': payload['fyi_request_id'],
                    'title': payload['title'],
                    'name': att.get('name') or '',
                    'url': att.get('url') or '',
                    'content_type': att.get('content_type') or '',
                    'size': att.get('size') or '',
                    'path': att.get('path') or '',
                }
            )
    return output


def response_analysis(db_path: str | Path, tracked_request_id: int) -> dict[str, Any]:
    row, snapshot = _base_follow_up_context(db_path, tracked_request_id)
    snapshot = snapshot or {}
    attachments = snapshot.get('attachments', [])
    events = snapshot.get('events', [])
    state = (snapshot.get('described_state') or '').lower()
    likely_response_received = bool(attachments or state in {'successful', 'partially_successful'} or events)
    likely_incomplete = state in {'partially_successful', 'waiting_response', 'internal_review', 'gone_postal'} or row.get('status') in {'submitted', 'awaiting_response', 'partial'}
    recommendation = 'Review released material and decide whether a clarification or completeness follow-up is needed.' if likely_response_received else 'No clear response detected yet; send a status-check follow-up if the request should have progressed.'
    if state in {'rejected', 'not_held'}:
        recommendation = 'Consider challenging the refusal, narrowing scope, or asking for transfer or clarification.'
    return {
        'tracked_request_id': tracked_request_id,
        'title': row['title'],
        'tracked_status': row['status'],
        'snapshot_state': snapshot.get('described_state'),
        'latest_snapshot_at': snapshot.get('fetched_at'),
        'attachments_count': len(attachments),
        'events_count': len(events),
        'likely_response_received': likely_response_received,
        'likely_incomplete': likely_incomplete,
        'recommendation': recommendation,
        'attachment_names': [a.get('name') for a in attachments if a.get('name')],
        'recent_event_titles': [e.get('title') for e in events[:5] if e.get('title')],
    }


def write_response_analysis(output_path: str | Path, db_path: str | Path, tracked_request_id: int) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = response_analysis(db_path, tracked_request_id)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return output
