from __future__ import annotations
import json
from pathlib import Path
from typing import Any
import requests
from .db import connect, query_all


def fetch_request_page(request_id: int, base_url: str = 'https://fyi.org.nz', db_path: str | Path = 'fyi_system.db', timeout: int = 20) -> dict:
    url = f"{base_url.rstrip('/')}/request/{request_id}.json"
    response = requests.get(url, timeout=timeout)
    response.raise_for_status()
    data = response.json()
    conn = connect(db_path)
    try:
        conn.execute(
            'INSERT INTO request_snapshots(fyi_request_id, source_url, raw_json) VALUES (?, ?, ?)',
            (request_id, url, json.dumps(data, ensure_ascii=False)),
        )
        conn.commit()
    finally:
        conn.close()
    return data


def _flatten_candidate_files(node: Any, path: str = 'root') -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    if isinstance(node, dict):
        keys = {str(k).lower() for k in node.keys()}
        has_url = any(k in keys for k in {'url', 'download_url', 'file_url'})
        has_name = any(k in keys for k in {'name', 'filename', 'file_name', 'title'})
        if has_url and has_name:
            found.append({
                'name': node.get('name') or node.get('filename') or node.get('file_name') or node.get('title') or 'attachment',
                'url': node.get('url') or node.get('download_url') or node.get('file_url') or '',
                'content_type': node.get('content_type') or node.get('mime_type') or '',
                'size': node.get('size') or node.get('byte_size') or node.get('content_length'),
                'path': path,
            })
        for key, value in node.items():
            found.extend(_flatten_candidate_files(value, f'{path}.{key}'))
    elif isinstance(node, list):
        for idx, value in enumerate(node):
            found.extend(_flatten_candidate_files(value, f'{path}[{idx}]'))
    return found


def _flatten_candidate_events(node: Any, path: str = 'root') -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    if isinstance(node, dict):
        keys = {str(k).lower() for k in node.keys()}
        eventish = bool(keys & {'event_type', 'incoming_message', 'outgoing_message', 'comment'}) or (path != 'root' and bool(keys & {'created_at', 'updated_at', 'described_state'}))
        if eventish:
            detail = node.get('title') or node.get('comment') or node.get('described_state') or node.get('event_type') or ''
            found.append({
                'title': node.get('title') or node.get('event_type') or node.get('described_state') or 'event',
                'detail': str(detail),
                'created_at': node.get('created_at') or node.get('updated_at') or node.get('sent_at') or node.get('last_event_forming_initial_request_at') or '',
                'path': path,
            })
        for key, value in node.items():
            found.extend(_flatten_candidate_events(value, f'{path}.{key}'))
    elif isinstance(node, list):
        for idx, value in enumerate(node):
            found.extend(_flatten_candidate_events(value, f'{path}[{idx}]'))
    return found


def _unique_items(items: list[dict[str, Any]], key_fields: tuple[str, ...]) -> list[dict[str, Any]]:
    seen: set[tuple[Any, ...]] = set()
    out: list[dict[str, Any]] = []
    for item in items:
        key = tuple(item.get(field) for field in key_fields)
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def extract_request_artifacts(data: dict) -> dict[str, Any]:
    nested = data.get('info_request', {}) if isinstance(data, dict) else {}
    attachments = _unique_items(_flatten_candidate_files(data), ('name', 'url', 'path'))
    events = _unique_items(_flatten_candidate_events(data), ('title', 'created_at', 'path'))
    return {
        'attachments': attachments,
        'events': events,
        'counts': {
            'attachments': len(attachments),
            'events': len(events),
        },
        'request': {
            'title': data.get('title') or nested.get('title'),
            'described_state': data.get('described_state') or nested.get('described_state'),
            'url_title': data.get('url_title') or nested.get('url_title'),
            'id': data.get('id') or nested.get('id'),
        },
    }


def summarize_request_json(data: dict) -> dict:
    nested = data.get('info_request', {}) if isinstance(data, dict) else {}
    artifacts = extract_request_artifacts(data)
    return {
        'title': data.get('title') or nested.get('title'),
        'described_state': data.get('described_state') or nested.get('described_state'),
        'url_title': data.get('url_title') or nested.get('url_title'),
        'attachments_count': artifacts['counts']['attachments'],
        'events_count': artifacts['counts']['events'],
    }


def latest_snapshot_summary(db_path: str | Path, fyi_request_id: int | None) -> dict | None:
    if fyi_request_id is None:
        return None
    rows = query_all(
        db_path,
        'SELECT raw_json, fetched_at, source_url FROM request_snapshots WHERE fyi_request_id=? ORDER BY fetched_at DESC, id DESC LIMIT 1',
        (fyi_request_id,),
    )
    if not rows:
        return None
    row = rows[0]
    data = json.loads(row['raw_json'])
    summary = summarize_request_json(data)
    artifacts = extract_request_artifacts(data)
    summary['attachments'] = artifacts['attachments']
    summary['events'] = artifacts['events']
    summary['fetched_at'] = row['fetched_at']
    summary['source_url'] = row['source_url']
    return summary
