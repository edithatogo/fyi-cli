from __future__ import annotations
import json
from pathlib import Path
from .db import query_all

def attention_report(db_path: str | Path = 'fyi_system.db') -> dict:
    rows = query_all(db_path, 'SELECT * FROM tracked_requests ORDER BY updated_at DESC, id DESC')
    items = []
    for row in rows:
        needs_attention = row['status'] in {'draft', 'open', 'awaiting'} or row['last_event_title'] is None
        items.append({
            'id': row['id'],
            'title': row['title'],
            'status': row['status'],
            'fyi_request_id': row['fyi_request_id'],
            'needs_attention': bool(needs_attention),
            'last_event_title': row['last_event_title'],
        })
    return {'count': len(items), 'items': items}

def write_attention_report(output_path: str | Path, db_path: str | Path = 'fyi_system.db') -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(attention_report(db_path), indent=2, ensure_ascii=False), encoding='utf-8')
    return output

def build_handover_markdown(db_path: str | Path = 'fyi_system.db') -> str:
    report = attention_report(db_path)
    lines = ['# FYI Request System Handover', '', f"Tracked requests: {report['count']}", '', '## Attention queue', '']
    for item in report['items']:
        marker = 'ACTION' if item['needs_attention'] else 'OK'
        lines.append(f"- [{marker}] #{item['id']} {item['title']} (status: {item['status']}, FYI: {item['fyi_request_id']})")
    return '\n'.join(lines) + '\n'

def write_handover(output_path: str | Path, db_path: str | Path = 'fyi_system.db') -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(build_handover_markdown(db_path), encoding='utf-8')
    return output
