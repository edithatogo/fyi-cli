from __future__ import annotations
import json
from pathlib import Path
import requests
from .db import connect

def fetch_request_page(request_id: int, base_url: str = 'https://fyi.org.nz', db_path: str | Path = 'fyi_system.db', timeout: int = 20) -> dict:
    url = f"{base_url.rstrip('/')}/request/{request_id}.json"
    response = requests.get(url, timeout=timeout)
    response.raise_for_status()
    data = response.json()
    conn = connect(db_path)
    try:
        conn.execute('INSERT INTO request_snapshots(fyi_request_id, source_url, raw_json) VALUES (?, ?, ?)', (request_id, url, json.dumps(data, ensure_ascii=False)))
        conn.commit()
    finally:
        conn.close()
    return data

def summarize_request_json(data: dict) -> dict:
    nested = data.get('info_request', {}) if isinstance(data, dict) else {}
    return {
        'title': data.get('title') or nested.get('title'),
        'described_state': data.get('described_state') or nested.get('described_state'),
        'url_title': data.get('url_title') or nested.get('url_title'),
    }
