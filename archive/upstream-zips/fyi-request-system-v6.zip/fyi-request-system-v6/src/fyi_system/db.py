from __future__ import annotations
import sqlite3
from pathlib import Path
from typing import Iterable, Any

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS authorities (
  slug TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  url TEXT
);
CREATE TABLE IF NOT EXISTS tracked_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  authority_slug TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  tags TEXT DEFAULT '',
  fyi_url TEXT,
  fyi_request_id INTEGER,
  status TEXT DEFAULT 'draft',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TEXT,
  last_event_title TEXT,
  FOREIGN KEY(authority_slug) REFERENCES authorities(slug)
);
CREATE TABLE IF NOT EXISTS feed_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  feed_url TEXT NOT NULL,
  event_id TEXT,
  title TEXT,
  link TEXT,
  published TEXT,
  summary TEXT,
  request_id_guess INTEGER,
  tracked_request_id INTEGER,
  raw_json TEXT,
  seen_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS request_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fyi_request_id INTEGER NOT NULL,
  source_url TEXT NOT NULL,
  raw_json TEXT NOT NULL,
  fetched_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS run_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_name TEXT NOT NULL,
  status TEXT NOT NULL,
  detail TEXT,
  ran_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


def connect(db_path: str | Path = 'fyi_system.db') -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: str | Path = 'fyi_system.db') -> None:
    conn = connect(db_path)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()


def query_all(db_path: str | Path, sql: str, params: Iterable[Any] = ()):
    conn = connect(db_path)
    try:
        return conn.execute(sql, tuple(params)).fetchall()
    finally:
        conn.close()


def insert_tracked_request(db_path: str | Path, authority_slug: str, title: str, body: str, tags: str = '', status: str = 'draft', fyi_request_id: int | None = None, fyi_url: str | None = None) -> int:
    conn = connect(db_path)
    try:
        cur = conn.execute(
            'INSERT INTO tracked_requests(authority_slug, title, body, tags, status, fyi_request_id, fyi_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
            (authority_slug, title, body, tags, status, fyi_request_id, fyi_url),
        )
        conn.commit()
        return int(cur.lastrowid)
    finally:
        conn.close()


def update_tracked_request(
    db_path: str | Path,
    request_id: int,
    *,
    authority_slug: str,
    title: str,
    body: str,
    tags: str = '',
    status: str = 'draft',
    fyi_request_id: int | None = None,
    fyi_url: str | None = None,
) -> None:
    conn = connect(db_path)
    try:
        conn.execute(
            """
            UPDATE tracked_requests
            SET authority_slug=?, title=?, body=?, tags=?, status=?, fyi_request_id=?, fyi_url=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=?
            """,
            (authority_slug, title, body, tags, status, fyi_request_id, fyi_url, request_id),
        )
        conn.commit()
    finally:
        conn.close()


def get_tracked_request(db_path: str | Path, request_id: int):
    rows = query_all(db_path, 'SELECT * FROM tracked_requests WHERE id=?', (request_id,))
    return rows[0] if rows else None
