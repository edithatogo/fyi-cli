from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .db import get_tracked_request, query_all, request_timeline
from .fetch import latest_snapshot_summary


def attention_report(db_path: str | Path = 'fyi_system.db') -> dict:
    rows = query_all(db_path, 'SELECT * FROM tracked_requests ORDER BY updated_at DESC, id DESC')
    items = []
    for row in rows:
        needs_attention = row['status'] in {'draft', 'open', 'awaiting'} or row['last_event_title'] is None
        items.append(
            {
                'id': row['id'],
                'title': row['title'],
                'status': row['status'],
                'fyi_request_id': row['fyi_request_id'],
                'needs_attention': bool(needs_attention),
                'last_event_title': row['last_event_title'],
            }
        )
    return {'count': len(items), 'items': items}


def write_attention_report(output_path: str | Path, db_path: str | Path = 'fyi_system.db') -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(attention_report(db_path), indent=2, ensure_ascii=False), encoding='utf-8')
    return output


def build_handover_markdown(db_path: str | Path = 'fyi_system.db') -> str:
    report = attention_report(db_path)
    lines = ['# FYI Request System Handover', '', f"Tracked requests: {report['count']}", '', '## Attention queue', '']
    for item in report['items']:
        marker = 'ACTION' if item['needs_attention'] else 'OK'
        lines.append(
            f"- [{marker}] #{item['id']} {item['title']} (status: {item['status']}, FYI: {item['fyi_request_id']})"
        )
        tl = request_timeline(db_path, item['id'])[:2]
        for ev in tl:
            lines.append(f"  - {ev['ts']}: {ev['title']}")
    return '\n'.join(lines) + '\n'


def write_handover(output_path: str | Path, db_path: str | Path = 'fyi_system.db') -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(build_handover_markdown(db_path), encoding='utf-8')
    return output


def suggest_follow_up(db_path: str | Path, tracked_request_id: int) -> dict[str, Any]:
    row = get_tracked_request(db_path, tracked_request_id)
    if not row:
        raise ValueError(f'Request {tracked_request_id} not found')

    snapshot = latest_snapshot_summary(db_path, row['fyi_request_id'])
    title = row['title']
    authority = row['authority_slug']
    status = (row['status'] or '').lower()
    snapshot_state = ((snapshot or {}).get('described_state') or '').lower()
    has_attachments = bool((snapshot or {}).get('attachments'))

    body_lines = [
        f'Kia ora {authority},',
        '',
        f'I’m following up on my request "{title}".',
    ]
    rationale = 'Generic follow-up based on tracked status.'
    stage = 'follow_up'

    if status == 'draft':
        rationale = 'Tracked request is still in draft and has not been submitted on FYI.'
        stage = 'submit_prompt'
        body_lines = [
            f'Draft ready for submission to {authority}.',
            '',
            f'Title: {title}',
            '',
            'Check the wording, confirm the authority, and submit through the prefilled FYI link.',
        ]
    elif snapshot_state in {'successful', 'partially_successful'} or has_attachments:
        rationale = 'Latest snapshot suggests a response or attachment is available.'
        stage = 'review_response'
        body_lines.extend(
            [
                'I can see that material may now be available on the request page.',
                'Could you please confirm whether this constitutes your full response, and whether any further material remains outstanding?',
                '',
                'If documents have been released, please identify any withheld material and the basis for any redactions or refusals.',
            ]
        )
    elif snapshot_state in {'waiting_response', 'internal_review', 'gone_postal'} or status in {'open', 'awaiting', 'submitted'}:
        rationale = 'Latest tracked state suggests the request is still active without a complete response.'
        stage = 'nudge'
        body_lines.extend(
            [
                'I would be grateful for an update on the status of this request.',
                'If a decision has been made, please provide the response and any released material through the FYI request page.',
                '',
                'If you need refinement or clarification, please let me know.',
            ]
        )
    elif snapshot_state in {'rejected', 'not_held'}:
        rationale = 'Latest snapshot indicates a refusal or not-held outcome.'
        stage = 'challenge_or_refine'
        body_lines.extend(
            [
                'I note the current outcome recorded on the request page.',
                'Please clarify whether any part of the requested information is held elsewhere within the agency, or whether the request can be narrowed or transferred.',
            ]
        )
    else:
        body_lines.extend(
            [
                'I would be grateful for an update on the current status of this request.',
                'Please let me know if any clarification would assist.',
            ]
        )

    body_lines.extend(['', 'Ngā mihi'])
    subject = f'Follow-up: {title}'
    return {
        'tracked_request_id': tracked_request_id,
        'subject': subject,
        'body': '\n'.join(body_lines).strip() + '\n',
        'stage': stage,
        'rationale': rationale,
        'snapshot_state': snapshot_state,
    }


def write_follow_up(output_path: str | Path, db_path: str | Path, tracked_request_id: int) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = suggest_follow_up(db_path, tracked_request_id)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return output


def attachment_manifest(db_path: str | Path, tracked_request_id: int) -> dict[str, Any]:
    row = get_tracked_request(db_path, tracked_request_id)
    if not row:
        raise ValueError(f'Request {tracked_request_id} not found')
    snapshot = latest_snapshot_summary(db_path, row['fyi_request_id']) or {}
    attachments = snapshot.get('attachments', [])
    return {
        'tracked_request_id': tracked_request_id,
        'fyi_request_id': row['fyi_request_id'],
        'title': row['title'],
        'attachments_count': len(attachments),
        'attachments': attachments,
    }


def write_attachment_manifest(output_path: str | Path, db_path: str | Path, tracked_request_id: int) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = attachment_manifest(db_path, tracked_request_id)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return output
