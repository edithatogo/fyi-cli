# Phase 4 plan

1. Add URL normalization and request ID extraction.
2. Reconcile unmatched events to tracked requests.
3. Generate HTML and JSON dashboards from SQLite.
4. Add tests and operator skill/prompt material.
