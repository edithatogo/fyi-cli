# Phase 4 spec

Add request-event reconciliation and a local operator dashboard.

## Goals
- Link ingested feed events back to tracked requests.
- Expose dashboard outputs in HTML and JSON.
- Preserve the local-first, human-in-the-loop workflow.
