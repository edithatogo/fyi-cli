from __future__ import annotations

import json
from pathlib import Path

from fyi_system.dashboard import write_dashboard_html, write_dashboard_json
from fyi_system.db import (
    connect,
    insert_feed_events,
    insert_request,
    reconcile_event_links,
    upsert_authorities,
    update_request_monitoring_fields,
)
from fyi_system.linking import canonical_request_url, extract_request_id
from fyi_system.models import Authority, FeedEntry, RequestRecord


def test_linking_helpers_normalize_request_urls() -> None:
    assert canonical_request_url('https://fyi.org.nz/request/123-test.json?unfold=1') == 'https://fyi.org.nz/request/123-test'
    assert extract_request_id('https://fyi.org.nz/request/123-test') == 123
    assert extract_request_id('https://fyi.org.nz/search/topic/feed') is None


def test_reconcile_event_links_matches_tracked_requests(tmp_path: Path) -> None:
    conn = connect(tmp_path / 'fyi.db')
    upsert_authorities(conn, [Authority(name='Authority', slug='authority')])
    request_id = insert_request(
        conn,
        RequestRecord(
            title='Tracked request',
            authority_slug='authority',
            request_url='https://fyi.org.nz/request/123-tracked-request',
            status='waiting_response',
        ),
    )
    insert_feed_events(
        conn,
        'https://fyi.org.nz/search/topic/feed',
        [FeedEntry(title='Update', link='https://fyi.org.nz/request/123-tracked-request')],
    )
    linked = reconcile_event_links(conn)
    assert linked == 1
    row = conn.execute('SELECT request_id FROM events').fetchone()
    assert row['request_id'] == request_id


def test_dashboard_outputs(tmp_path: Path) -> None:
    conn = connect(tmp_path / 'fyi.db')
    upsert_authorities(conn, [Authority(name='Authority', slug='authority')])
    request_id = insert_request(
        conn,
        RequestRecord(
            title='Tracked request',
            authority_slug='authority',
            request_url='https://fyi.org.nz/request/123-tracked-request',
            status='waiting_response',
        ),
    )
    update_request_monitoring_fields(
        conn,
        request_id,
        status='waiting_response',
        due_date='2026-03-01',
        last_public_update_at='2026-02-01T12:00:00Z',
    )
    html_path = tmp_path / 'dashboard.html'
    json_path = tmp_path / 'dashboard.json'
    write_dashboard_html(conn, html_path, as_of_date='2026-03-08', stale_days=30)
    write_dashboard_json(conn, json_path, as_of_date='2026-03-08', stale_days=30)
    html_text = html_path.read_text(encoding='utf-8')
    assert 'FYI Request Dashboard' in html_text
    payload = json.loads(json_path.read_text(encoding='utf-8'))
    assert payload['total_requests'] == 1
    assert payload['attention'][0]['title'] == 'Tracked request'
