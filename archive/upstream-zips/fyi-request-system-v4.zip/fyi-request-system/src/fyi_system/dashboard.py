from __future__ import annotations

import html
import json
from pathlib import Path

from .db import get_dashboard_rows


def write_dashboard_html(db_conn, output: Path, *, as_of_date: str, stale_days: int = 30) -> None:
    rows = get_dashboard_rows(db_conn, as_of_date=as_of_date, stale_days=stale_days)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_dashboard_html(rows, as_of_date=as_of_date, stale_days=stale_days), encoding='utf-8')


def write_dashboard_json(db_conn, output: Path, *, as_of_date: str, stale_days: int = 30) -> None:
    rows = get_dashboard_rows(db_conn, as_of_date=as_of_date, stale_days=stale_days)
    payload = {
        'total_requests': rows['total_requests'],
        'status_counts': [dict(row) for row in rows['status_counts']],
        'attention': [dict(row) for row in rows['attention']],
        'recently_updated': [dict(row) for row in rows['recently_updated']],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')


def render_dashboard_html(rows: dict, *, as_of_date: str, stale_days: int) -> str:
    status_rows = ''.join(
        f"<tr><td>{html.escape(row['status'])}</td><td>{row['count']}</td></tr>" for row in rows['status_counts']
    ) or '<tr><td colspan="2">No requests yet.</td></tr>'
    attention_rows = ''.join(
        '<tr>'
        f"<td>{row['id']}</td>"
        f"<td>{html.escape(row['title'])}</td>"
        f"<td>{html.escape(row['authority_slug'])}</td>"
        f"<td>{html.escape(row['attention_state'])}</td>"
        f"<td>{html.escape(row['due_date'] or '')}</td>"
        f"<td>{html.escape(row['last_public_update_at'] or '')}</td>"
        '</tr>' for row in rows['attention']
    ) or '<tr><td colspan="6">No overdue or stalled requests.</td></tr>'
    recent_rows = ''.join(
        '<tr>'
        f"<td>{row['id']}</td>"
        f"<td>{html.escape(row['title'])}</td>"
        f"<td>{html.escape(row['status'])}</td>"
        f"<td>{html.escape(row['last_public_update_at'] or '')}</td>"
        '</tr>' for row in rows['recently_updated']
    ) or '<tr><td colspan="4">No recent public updates.</td></tr>'
    return f'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>FYI Request Dashboard</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 2rem; color: #222; }}
    .cards {{ display: flex; gap: 1rem; margin-bottom: 1.5rem; }}
    .card {{ border: 1px solid #ddd; border-radius: 8px; padding: 1rem; min-width: 220px; }}
    table {{ border-collapse: collapse; width: 100%; margin-bottom: 1.5rem; }}
    th, td {{ border: 1px solid #ddd; padding: 0.5rem; text-align: left; }}
    th {{ background: #f5f5f5; }}
  </style>
</head>
<body>
  <h1>FYI Request Dashboard</h1>
  <p>As of {html.escape(as_of_date)} · Stale threshold {stale_days} days</p>
  <div class="cards">
    <div class="card"><strong>Total requests</strong><div>{rows['total_requests']}</div></div>
    <div class="card"><strong>Attention items</strong><div>{len(rows['attention'])}</div></div>
    <div class="card"><strong>Recently updated tracked requests</strong><div>{len(rows['recently_updated'])}</div></div>
  </div>
  <h2>Status counts</h2>
  <table><thead><tr><th>Status</th><th>Count</th></tr></thead><tbody>{status_rows}</tbody></table>
  <h2>Attention queue</h2>
  <table><thead><tr><th>ID</th><th>Title</th><th>Authority</th><th>State</th><th>Due date</th><th>Last public update</th></tr></thead><tbody>{attention_rows}</tbody></table>
  <h2>Recently updated</h2>
  <table><thead><tr><th>ID</th><th>Title</th><th>Status</th><th>Last public update</th></tr></thead><tbody>{recent_rows}</tbody></table>
</body>
</html>
'''
