from __future__ import annotations

from urllib.parse import urlsplit, urlunsplit


def canonical_request_url(url: str | None) -> str | None:
    if not url:
        return None
    parts = urlsplit(url)
    path = parts.path.removesuffix('.json').rstrip('/')
    if path.endswith('/feed'):
        path = path[:-5]
    return urlunsplit((parts.scheme, parts.netloc, path, '', ''))


def extract_request_id(url: str | None) -> int | None:
    canonical = canonical_request_url(url)
    if not canonical:
        return None
    path = urlsplit(canonical).path.strip('/').split('/')
    if len(path) < 2 or path[0] != 'request':
        return None
    head = path[1].split('-', 1)[0]
    return int(head) if head.isdigit() else None
