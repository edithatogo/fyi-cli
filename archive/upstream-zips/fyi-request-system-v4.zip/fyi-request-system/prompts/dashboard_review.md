Review the generated FYI dashboard and produce:
1. the top operational risks,
2. the requests that need immediate follow-up,
3. any anomalies in status counts or stale dates,
4. a short operator handover note.
