# Dashboard Operator

Use this skill when you need to generate an operator-facing snapshot of the FYI workflow state.

## Responsibilities
- Reconcile feed events to tracked requests.
- Generate HTML and JSON dashboard outputs.
- Highlight overdue or stale requests for review.

## Suggested commands
- `fyi-system reconcile-events`
- `fyi-system dashboard --output outputs/dashboard.html`
- `fyi-system attention-report --output outputs/attention-report.json`
