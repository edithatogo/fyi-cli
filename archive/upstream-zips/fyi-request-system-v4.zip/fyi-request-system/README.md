# FYI Request System

A Conductor-oriented, local-first repository for managing an assisted FYI.org.nz request workflow.

This repo is designed around the reality that FYI exposes useful API-like surfaces, but not a full submission-management API. It therefore supports:
- authority import and local indexing
- draft generation for prefilled FYI request URLs
- local request registration before submission
- feed polling and feed snapshot diffing
- per-request JSON ingestion for monitoring fields
- overdue and stalled-request reports
- markdown handovers for operator continuity

## Why this design

FYI says it does **not have a full API yet**, but it does provide API-like features including prefilled request URLs, Atom feeds, JSON versions of many pages, and a CSV export of authorities. That supports an assisted workflow rather than a fully headless one. citeturn0search1turn0search2turn0search4

Conductor is built around persistent project context and a `Context -> Spec & Plan -> Implement` lifecycle with project files and per-track plans. This repo follows that pattern in `conductor/` and `conductor/tracks/`. citeturn0search0turn0search8turn0search14

## Repo layout

```text
conductor/                 # Context, product docs, workflow, tracks
conductor/tracks/          # Track-specific specs and plans
prompts/                   # Prompt packs for drafting, review, handover
skills/                    # Local skill docs for repeatable operator workflows
src/fyi_system/            # Python package + CLI
scripts/                   # Example shell usage and setup notes
docs/architecture/         # Design notes
docs/handover/             # Operator handover docs
outputs/                   # Generated reports and handovers
```

## Recommended supporting tools

Core:
- Python 3.10+
- `uv` or `pip`
- SQLite
- Gemini CLI + Conductor extension

Useful additions:
- Ralph for iterative refinement loops on specs/prompts
- `pre-commit`
- `ruff`
- `mypy`
- `pytest-cov`
- `just` or `make`

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
```

## Example workflow

```bash
fyi-system init-db
fyi-system import-authorities data/all-authorities.csv
fyi-system register-request auckland_council "Service metrics request" "Please provide..." --tags "topic:metrics"
fyi-system list-requests
fyi-system ingest-feed "https://fyi.org.nz/search/service/feed"
fyi-system fetch-request-page 1
fyi-system attention-report --output outputs/attention-report.json
fyi-system handover --output outputs/handover.md
```

## Commands

- `init-db` — create the local SQLite schema
- `draft-url` — build a prefilled FYI request URL
- `register-request` — save a local request record before submission
- `import-authorities` — import a CSV of authorities
- `list-authorities` — inspect imported authorities
- `list-requests` — inspect local request records
- `poll-feed` — fetch a feed and write JSON to disk
- `ingest-feed` — persist feed events and snapshot diffs to SQLite
- `fetch-request-page` — fetch `request_url + .json`, normalize monitoring fields, and save them
- `attention-report` — produce a JSON report of overdue/stalled items
- `handover` — produce a markdown handover from the local DB

## Notes on networking and privacy

This repository is intended for ordinary, transparent access to public FYI resources and user-initiated FYI submissions. It does not include Tor, proxy-chaining, IP masking, or other identity-evasion infrastructure.


## Phase 4 additions

- Event-to-request reconciliation based on FYI request links
- HTML and JSON dashboard generation
- Automatic linking during feed ingestion

Example commands:

```bash
fyi-system reconcile-events
fyi-system dashboard --output outputs/dashboard.html
```
